/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package au.edu.unsw.business.infs2605.fxstarterkit;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class AboutController {
    
    @FXML
    Button logout, about, home, supplier;
    
    private void switchtoHome() throws IOException {
        App.setRoot("Home");
    }
    
    @FXML
    public void handleHomeButton() throws IOException {
        switchtoHome();
    }
    
    private void switchtoSuppliers() throws IOException {
        App.setRoot("Supplier");
    }
    
    @FXML
    public void handleSupplierButton() throws IOException{
        switchtoSuppliers();
    }
    
    private void switchtoOrder() throws IOException {
        App.setRoot("Order");
    }
    
    @FXML
    public void handleOrderButton() throws IOException {
        switchtoOrder();
    }
    
    private void switchtoLogin() throws IOException{
        App.setRoot("Login");
    }
    
    @FXML
    public void handleLogOutButton() throws IOException{
        EmployeeSupplier.falseUserAvailable();
        switchtoLogin();
    }
    
    private void switchtoAbout() throws IOException{
        App.setRoot("About");
    }
    
    @FXML
    public void handleAboutButton() throws IOException{
        switchtoAbout();
    }
    
    
}
