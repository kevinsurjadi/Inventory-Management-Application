package au.edu.unsw.business.infs2605.fxstarterkit;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;


public class SupplierController {
    
    @FXML
    TableView suppliersTable;
    @FXML
    Button createSupplier;
    @FXML
    Button editSupplier;
    @FXML
    TableColumn<Suppliers, String> supplier_id;
    @FXML
    TableColumn<Suppliers, String> supplier_name;
    @FXML
    TableColumn<Suppliers, String> phone_number;
    @FXML
    TableColumn<Suppliers, String> address; 
    @FXML
    TableColumn<Suppliers, String> employee_id; 
    @FXML
    TextField supplier_idInput;
    @FXML
    TextField supplier_nameInput;
    @FXML
    TextField phone_numberInput;
    @FXML
    TextField addressInput;
    @FXML
    TextField employee_idInput;
    @FXML
    Button home;
    @FXML
    Button suppliers;
    @FXML
    Button about;
    @FXML
    Button logOut;
    
    Database database= new Database();
    
    ObservableList<Suppliers> suppliersList= FXCollections.observableArrayList();
    
    int index=-1;
    
    //button root functionalities
    
    private void switchtoHome() throws IOException {
        App.setRoot("Home");
    }
    
    @FXML
    public void handleHomeButton() throws IOException {
        switchtoHome();
    }
    
    private void switchtoSuppliers() throws IOException {
        App.setRoot("Supplier");
    }
    
    @FXML
    public void handleSupplierButton() throws IOException{
        switchtoSuppliers();
    }
    
    private void switchtoOrder() throws IOException {
        App.setRoot("Order");
    }
    
    @FXML
    public void handleOrderButton() throws IOException {
        switchtoOrder();
    }
    
    private void switchtoLogin() throws IOException{
        App.setRoot("Login");
    }
    
    @FXML
    public void handleLogOutButton() throws IOException{
        EmployeeSupplier.falseUserAvailable();
        switchtoLogin();
    }
    
    private void switchtoAbout() throws IOException{
        App.setRoot("About");
    }
    
    @FXML
    public void handleAboutButton() throws IOException{
        switchtoAbout();
    }
    
    //CONNECT TABLE WITH DATABASE
    @FXML
    public void initialize() throws SQLException{
        // Create the table
        suppliersList= database.getSuppliers();
        suppliersTable.setItems(suppliersList);
        supplier_id.setCellValueFactory(new PropertyValueFactory<>("supplier_id"));
        supplier_name.setCellValueFactory(new PropertyValueFactory<>("supplier_name"));
        phone_number.setCellValueFactory(new PropertyValueFactory<>("phone_number"));
        address.setCellValueFactory(new PropertyValueFactory<>("address"));
        employee_id.setCellValueFactory(new PropertyValueFactory<>("employee_id"));
        suppliersTable.setEditable(true);
    }
    
    //Allows the user to click on an entry in the tableview which then adds text to the Textfield.
    @FXML
    public void getSelected(MouseEvent event){
    index= suppliersTable.getSelectionModel().getSelectedIndex();
    if(index<=-1){
        
        return;
    }
  
    supplier_idInput.setText(supplier_id.getCellData(index).toString());
    supplier_nameInput.setText(supplier_name.getCellData(index).toString());
    phone_numberInput.setText(phone_number.getCellData(index).toString());
    addressInput.setText(address.getCellData(index).toString());
    employee_idInput.setText(employee_id.getCellData(index).toString());
}
    
    //REFRESHS TABLE. Used after User changes the TableView through the buttons.
    @FXML
    public void handleRefresh() throws SQLException{
        suppliersList= database.getSuppliers();
        suppliersTable.setItems(suppliersList);
        supplier_id.setCellValueFactory(new PropertyValueFactory<>("supplier_id"));
        supplier_name.setCellValueFactory(new PropertyValueFactory<>("supplier_name"));
        phone_number.setCellValueFactory(new PropertyValueFactory<>("phone_number"));
        address.setCellValueFactory(new PropertyValueFactory<>("address"));
        employee_id.setCellValueFactory(new PropertyValueFactory<>("employee_id"));
        suppliersTable.setEditable(true);
    }

    //CREATE SUPPLIER BUTTON
    @FXML
    public void handleCreateSupplier() throws SQLException{
        String supplier_id= supplier_idInput.getText();
        String supplier_name= supplier_nameInput.getText();
        String phone_number= phone_numberInput.getText();
        String address= addressInput.getText();
        String employee_id= employee_idInput.getText();
       Connection conn= DriverManager.getConnection("jdbc:sqlite:database.db");
       PreparedStatement ps= conn.prepareStatement("INSERT INTO SUPPLIER (SUPPLIER_ID, SUPPLIER_NAME, PHONE_NUMBER, ADDRESS, EMPLOYEE_ID) "
       + "VALUES(?,?, ?, ?,?);");
       ps.setString(1, supplier_id);
       ps.setString(2, supplier_name);
       ps.setString(3, phone_number);
       ps.setString(4, address);
       ps.setString(5, employee_id);
       ps.executeUpdate();
       ps.close();
       conn.close();
       handleRefresh(); //Calls on the Refresh Method 
    }
    
    //EDIT SUPPLIER BUTTON
    @FXML
    public void handleUpdateSupplierButton() throws SQLException{
        String supplier_id= supplier_idInput.getText();
        String supplier_name= supplier_nameInput.getText();
        String phone_number= phone_numberInput.getText();
        String address= addressInput.getText();
        String employee_id= employee_idInput.getText();
        Connection conn= DriverManager.getConnection("jdbc:sqlite:database.db");
        PreparedStatement ps= conn.prepareStatement("UPDATE SUPPLIER SET SUPPLIER_NAME=?, PHONE_NUMBER=?, ADDRESS=?, EMPLOYEE_ID=? WHERE SUPPLIER_ID=?;");
        ps.setString(1, supplier_name );
        ps.setString(2, phone_number);
        ps.setString(3, address);
        ps.setString(4, employee_id);
        ps.setString(5, supplier_id);
        ps.executeUpdate();
        ps.close();
        conn.close();
        handleRefresh();
}
}