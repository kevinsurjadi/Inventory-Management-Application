/*
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package au.edu.unsw.business.infs2605.fxstarterkit;
import java.sql.*;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.chart.PieChart;
/**
 *
 * @author ama32
 */
public class Database {
    public void initialise() throws ClassNotFoundException, SQLException{
        
    }
        
    public void userTable() throws ClassNotFoundException, SQLException{ //used to create User Table

 Class.forName("org.sqlite.JDBC");
        Connection conn= DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st= conn.createStatement();
        String createStatement= "CREATE TABLE IF NOT EXISTS USER " +
                "(USER_ID TEXT PRIMARY KEY NOT NULL, "
                +"USERNAME TEXT NOT NULL, "
                +"PASSWORD TEXT NOT NULL, "
                +"FULL_NAME TEXT NOT NULL,"
                +"USER_TYPE TEXT NOT NULL);";
        st.execute(createStatement);
            ArrayList<String>insertStatements= new ArrayList<String>();
        insertStatements.add(
        "INSERT INTO USER (USER_ID, USERNAME, PASSWORD, FULL_NAME, USER_TYPE) "
        + "VALUES('U01', 'storemanager1', '1234', 'David Nguyen', 'Store Manager');"
        );
        insertStatements.add(
        "INSERT INTO USER (USER_ID, USERNAME, PASSWORD, FULL_NAME, USER_TYPE) "
        + "VALUES('U02', 'storemanager2', '5678', 'Ryan Phung', 'Store Manager');"
        );
        insertStatements.add(
        "INSERT INTO USER (USER_ID, USERNAME, PASSWORD, FULL_NAME, USER_TYPE) "
        + "VALUES('U03', 'storemanager3', '91011', 'Bart Simpson', 'Store Manager');"
        );
        insertStatements.add(
        "INSERT INTO USER (USER_ID, USERNAME, PASSWORD, FULL_NAME, USER_TYPE) "
        + "VALUES('U04', 'supplier1', '1234', 'John Smith', 'Supplier');"
        );
        insertStatements.add(
        "INSERT INTO USER (USER_ID, USERNAME, PASSWORD, FULL_NAME, USER_TYPE) "
        + "VALUES('U05', 'supplier2', '1234', 'James Lu', 'Supplier');"
        );
        insertStatements.add(
        "INSERT INTO USER (USER_ID, USERNAME, PASSWORD, FULL_NAME, USER_TYPE) "
        + "VALUES('U06', 'supplier3', '1234', 'Tony Stark', 'Supplier');"
        );
        insertStatements.add(
        "INSERT INTO USER (USER_ID, USERNAME, PASSWORD, FULL_NAME, USER_TYPE) "
        + "VALUES('U07', 'supplier4', '1234', 'Yuan Fan', 'Supplier');"
        );
        
        for(String thisStatement: insertStatements){
            st.execute(thisStatement);
        }
        st.close();
        conn.close();
}
    public void storeTable() throws SQLException, ClassNotFoundException{ //used to create store table
         Class.forName("org.sqlite.JDBC");
        Connection conn= DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st= conn.createStatement();
        String createStatement2= "CREATE TABLE IF NOT EXISTS STORE " +
                "(STORE_ID TEXT PRIMARY KEY NOT NULL, "
                +"ADDRESS TEXT NOT NULL, "
                +"PHONE_NUMBER INTEGER NOT NULL, "
                +"STORE_MANAGER TEXT NOT NULL, "
                +"FOREIGN KEY (STORE_MANAGER) REFERENCES USER (USER_ID))";
        st.execute(createStatement2);
        ArrayList<String>insertStatements2= new ArrayList<String>();
        insertStatements2.add(
        "INSERT INTO STORE (STORE_ID, ADDRESS, PHONE_NUMBER, STORE_MANAGER) "
        + "VALUES('S01', '14 ANZAC PARADE KENSINGTON NSW', '0450460929', 'U01');"
        );
        insertStatements2.add(
        "INSERT INTO STORE (STORE_ID, ADDRESS, PHONE_NUMBER, STORE_MANAGER) "
        + "VALUES('S02', '52 Fifth Avenue Bankstown NSW', '0456782045', 'U02');"
        );
        insertStatements2.add(
        "INSERT INTO STORE (STORE_ID, ADDRESS, PHONE_NUMBER, STORE_MANAGER) "
        + "VALUES('S03', '89 Wall Street Ultimo VIC', '0456201234', 'U03');"
        );
        
        for(String thisStatement: insertStatements2){
            st.execute(thisStatement);
        }
        st.close();
        conn.close();
    }
    public void productTable() throws SQLException{ //used to create product table
        Connection conn= DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st= conn.createStatement();
        String createStatement3= "CREATE TABLE IF NOT EXISTS PRODUCT " +
                "(PRODUCT_ID TEXT PRIMARY KEY NOT NULL, "
                +"PRODUCT_NAME TEXT NOT NULL, "
                +"PRICE DOUBLE NOT NULL, "
                +"PRODUCT_TYPE TEXT NOT NULL)";
        st.execute(createStatement3);
          ArrayList<String>insertStatements3= new ArrayList<String>();
        insertStatements3.add(
        "INSERT INTO PRODUCT (PRODUCT_ID, PRODUCT_NAME, PRICE, PRODUCT_TYPE) "
        + "VALUES('P01', 'Razer Deathadder', '50', 'Gaming');"
        );
        insertStatements3.add(
        "INSERT INTO PRODUCT (PRODUCT_ID, PRODUCT_NAME, PRICE, PRODUCT_TYPE) "
        + "VALUES('P02', 'Carrots 1KG', '1.40', 'Foods');"
        );
        insertStatements3.add(
        "INSERT INTO PRODUCT (PRODUCT_ID, PRODUCT_NAME, PRICE, PRODUCT_TYPE) "
        + "VALUES('P03', 'Samsung Microwave', '500', 'Appliances');"
        );
        insertStatements3.add( 
        "INSERT INTO PRODUCT (PRODUCT_ID, PRODUCT_NAME, PRICE, PRODUCT_TYPE) "
        + "VALUES('P04', 'Surface Laptop 3', '1699.00', 'Appliances');"
        );
        insertStatements3.add( 
        "INSERT INTO PRODUCT (PRODUCT_ID, PRODUCT_NAME, PRICE, PRODUCT_TYPE) "
        + "VALUES('P05', 'Chocolate Mudcake', '4.80', 'Baked Goods');"
        );
        insertStatements3.add( 
        "INSERT INTO PRODUCT (PRODUCT_ID, PRODUCT_NAME, PRICE, PRODUCT_TYPE) "
        + "VALUES('P06', 'Heavy Duty Wipes', '6.29', 'Household Cleaning');"
        );
        insertStatements3.add( 
        "INSERT INTO PRODUCT (PRODUCT_ID, PRODUCT_NAME, PRICE, PRODUCT_TYPE) "
        + "VALUES('P07', 'Panadol Pain Relief 100 Tablets', '12.99', 'Pharmacy');"
        );
        insertStatements3.add( 
        "INSERT INTO PRODUCT (PRODUCT_ID, PRODUCT_NAME, PRICE, PRODUCT_TYPE) "
        + "VALUES('P08', 'Pedigree Adult Wet Dogfood', '45.27', 'Pet');"
        );
        
        for(String thisStatement: insertStatements3){
            st.execute(thisStatement);
        }
        st.close();
        conn.close();
    }
    public void orderTable() throws SQLException{ //used to create order table
        Connection conn= DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st= conn.createStatement();
        String createQuery= "CREATE TABLE IF NOT EXISTS ORDERS " +
                "(ORDER_ID TEXT PRIMARY KEY NOT NULL, "
                +"STATUS TEXT NOT NULL);";
        st.execute(createQuery);
        
             ArrayList<String>insertStatements= new ArrayList<String>();
        insertStatements.add(
        "INSERT INTO ORDERS (ORDER_ID, STATUS) "
        + "VALUES('O01', 'Order Placed');"
        );
        insertStatements.add(
        "INSERT INTO ORDERS(ORDER_ID, STATUS) "
        + "VALUES('O02', 'Order Placed');"
        );
        insertStatements.add(
        "INSERT INTO ORDERS (ORDER_ID, STATUS) "
        + "VALUES('O03', 'Order Placed');"
        );
        
        for(String thisStatement: insertStatements){
            st.execute(thisStatement);
        }
        st.close();
        conn.close();
    }
    public void orderProductTable() throws SQLException{ // creates orderproduct table
        Connection conn= DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st= conn.createStatement();
        String createQuery= "CREATE TABLE IF NOT EXISTS ORDERPRODUCT " +
                "(ORDER_ID TEXT NOT NULL, "
                +"PRODUCT_ID TEXT NOT NULL, "
                +"SUPPLIER_ID TEXT NOT NULL, "
                +"QUANTITY INTEGER NOT NULL, "
                +"ORDER_TIMESTAMP TEXT NOT NULL, "
                +"PRIMARY KEY (ORDER_ID, PRODUCT_ID, SUPPLIER_ID), "
                +"FOREIGN KEY (ORDER_ID) REFERENCES ORDERS (ORDER_ID), "
                +"FOREIGN KEY (PRODUCT_ID) REFERENCES PRODUCT (PRODUCT_ID), "
                +"FOREIGN KEY (SUPPLIER_ID) REFERENCES SUPPLIER (SUPPLIER_ID));";
          st.execute(createQuery);
            ArrayList<String>insertStatements4= new ArrayList<String>();
        insertStatements4.add(
        "INSERT INTO ORDERPRODUCT (ORDER_ID, PRODUCT_ID, SUPPLIER_ID, QUANTITY, ORDER_TIMESTAMP) "
        + "VALUES('O01', 'P01', 'SP01', '1', '2020-10-31 15:14:52:43');"
        );
        insertStatements4.add(
        "INSERT INTO ORDERPRODUCT (ORDER_ID, PRODUCT_ID, SUPPLIER_ID, QUANTITY, ORDER_TIMESTAMP) "
        + "VALUES('O02', 'P02', 'SP01', '2', '2020-11-04 12:30:10:15');"
        );
        insertStatements4.add(
        "INSERT INTO ORDERPRODUCT (ORDER_ID, PRODUCT_ID, SUPPLIER_ID, QUANTITY, ORDER_TIMESTAMP) "
        + "VALUES('O03', 'P03', 'SP01', '3','2020-11-04 17:23:34:01');"
        );
        
        for(String thisStatement: insertStatements4){
            st.execute(thisStatement);
        }
        st.close();
        conn.close();
    }
    public void supplierTable() throws SQLException{ //creates supplier table
        Connection conn= DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st= conn.createStatement();
       
      
        String createStatement5= "CREATE TABLE IF NOT EXISTS SUPPLIER " +
                "(SUPPLIER_ID TEXT PRIMARY KEY NOT NULL , "
                +"SUPPLIER_NAME TEXT NOT NULL, "
                +"PHONE_NUMBER TEXT NOT NULL, "
                +"ADDRESS TEXT NOT NULL, "
                +"EMPLOYEE_ID TEXT NOT NULL,"
                +"FOREIGN KEY (EMPLOYEE_ID) REFERENCES USER(USER_ID));";
        st.execute(createStatement5);
         
          ArrayList<String>insertStatements5= new ArrayList<String>();
        insertStatements5.add(
        "INSERT INTO SUPPLIER (SUPPLIER_ID, SUPPLIER_NAME, PHONE_NUMBER, ADDRESS, EMPLOYEE_ID)"
        + "VALUES('SP01', 'RAZOR', '0456783056','56 Anzac Parade Kensington 2033', 'U04');"
        
        );
        insertStatements5.add(
        "INSERT INTO SUPPLIER (SUPPLIER_ID, SUPPLIER_NAME, PHONE_NUMBER, ADDRESS, EMPLOYEE_ID)"
        + "VALUES('SP02', 'OZTRAIL', '0456723056','18 Anzac Parade Kensington 2033','U05');"
        
        );
        insertStatements5.add(
        "INSERT INTO SUPPLIER (SUPPLIER_ID, SUPPLIER_NAME, PHONE_NUMBER, ADDRESS, EMPLOYEE_ID)"
        + "VALUES('SP03', 'Samsung', '0456783056','23 Anzac Parade Kensington 2033','U06');"
        
        );
        insertStatements5.add(
        "INSERT INTO SUPPLIER (SUPPLIER_ID, SUPPLIER_NAME, PHONE_NUMBER, ADDRESS, EMPLOYEE_ID)"
        + "VALUES('SP04', 'Microsoft', '0452783056','18 Anzac Parade Kensington 2033','U07');"
        
        );
        for(String thisStatement: insertStatements5){
            st.execute(thisStatement);
        }
        st.close();
        conn.close();
        
    }  
     public void DropTable() throws SQLException, ClassNotFoundException{ //used to drop a table. You can change the query to drop any table in the database
        Class.forName("org.sqlite.JDBC");
        Connection conn= DriverManager.getConnection("jdbc:sqlite:database.db");
        Statement st= conn.createStatement();
        String query= "DROP TABLE USER";
        st.execute(query);
        st.close();
        conn.close();
        
   }
     public String login(String username, String password) throws SQLException{ //Used to login user to the systems. Works by checking username and password through a prepared statement and result set seeing if results match entries in the User tABLE
        Connection conn=DriverManager.getConnection("jdbc:sqlite:database.db");
        PreparedStatement ps=conn.prepareStatement("SELECT * FROM USER WHERE USERNAME=? AND PASSWORD=?");
        ps.setString(1, username);
        ps.setString(2, password);
        ResultSet rs= ps.executeQuery();
        if(rs.getString("USER_TYPE").equals("Supplier")){
        String user_id= rs.getString("USER_ID");
        PreparedStatement ps2=conn.prepareStatement("SELECT SUPPLIER_ID FROM SUPPLIER WHERE EMPLOYEE_ID=? ");
        ps2.setString(1, user_id);
        ResultSet rs2= ps2.executeQuery();
        String supplier_id= rs2.getString("SUPPLIER_ID");
        ps.close();
        ps2.close();
        conn.close();
        return supplier_id; //for AF1 requirement supplier user. Gets the Supplier ID based on the Employee_ID which is a new entry we created in the Supplier Table and is a Foreign Key to USER_ID
        }
        else if(rs.getString("USER_TYPE").equals("Store Manager")){
            ps.close();
            conn.close();
        return "store manager"; // returns storemanager to let system know it is Store Manager and hence doesn't need a supplier_id.
        }
        
     return "none";
     }
     
       public ObservableList<Orders> getOrders() throws SQLException{ //USed to create return observable list for tableview for Orders for store manager user
       Connection conn=DriverManager.getConnection("jdbc:sqlite:database.db");
       Statement st= conn.createStatement();
       String query= "SELECT ORDER_ID, PRODUCT_ID, SUPPLIER_ID, QUANTITY, STATUS, ORDER_TIMESTAMP, PRODUCT_NAME, PRICE* QUANTITY AS TOTAL_PRICE FROM ORDERPRODUCT JOIN PRODUCT USING(PRODUCT_ID) JOIN ORDERS USING(ORDER_ID) ORDER BY ORDER_ID;";
       ResultSet rs= st.executeQuery(query);
       ObservableList<Orders> ordersList= FXCollections.observableArrayList();
       while(rs.next()){
           ordersList.add(new Orders(rs.getString("ORDER_ID"), rs.getString("PRODUCT_ID"), rs.getString("SUPPLIER_ID"), rs.getInt("QUANTITY"),rs.getString("STATUS"),rs.getString("ORDER_TIMESTAMP"),rs.getString("PRODUCT_NAME"),rs.getDouble("TOTAL_PRICE")));
       }
       st.close();
       conn.close();
       return ordersList;
       
       }
       public ObservableList<Orders> getOrdersforSupplierUser(String supplier_id) throws SQLException{ //used to create order for Suppliers. Takes in a String which is the Supplier_id which is then used in a prepared statement to filter out the orders so only orders for a certain supplier is displayed fufilling AF1 requirement.
       Connection conn=DriverManager.getConnection("jdbc:sqlite:database.db");
       PreparedStatement ps=conn.prepareStatement("SELECT ORDER_ID, PRODUCT_ID, SUPPLIER_ID, QUANTITY, STATUS, ORDER_TIMESTAMP, PRODUCT_NAME, PRICE* QUANTITY AS TOTAL_PRICE FROM ORDERPRODUCT JOIN PRODUCT USING(PRODUCT_ID) JOIN ORDERS USING(ORDER_ID) WHERE SUPPLIER_ID=? ORDER BY ORDER_ID;");
       ps.setString(1, supplier_id);
       ResultSet rs= ps.executeQuery();
       ObservableList<Orders> ordersList= FXCollections.observableArrayList();
       while(rs.next()){
           ordersList.add(new Orders(rs.getString("ORDER_ID"), rs.getString("PRODUCT_ID"), rs.getString("SUPPLIER_ID"), rs.getInt("QUANTITY"),rs.getString("STATUS"),rs.getString("ORDER_TIMESTAMP"),rs.getString("PRODUCT_NAME"),rs.getDouble("TOTAL_PRICE")));
       }
       ps.close();
       conn.close();
       return ordersList;
       }
       
       
       public ObservableList<Suppliers> getSuppliers() throws SQLException{ //Used to create observabile list for tableview for supplier table in the supplier page.
       Connection conn=DriverManager.getConnection("jdbc:sqlite:database.db");
       Statement st= conn.createStatement();
       String query= "SELECT SUPPLIER_ID, SUPPLIER_NAME, PHONE_NUMBER, ADDRESS, EMPLOYEE_ID FROM SUPPLIER;";
       ResultSet rs= st.executeQuery(query);
       ObservableList<Suppliers> suppliersList= FXCollections.observableArrayList();
       while(rs.next()){
           suppliersList.add(new Suppliers(rs.getString("SUPPLIER_ID"), rs.getString("SUPPLIER_NAME"), rs.getString("PHONE_NUMBER"),rs.getString("ADDRESS"),rs.getString("EMPLOYEE_ID")));
       }
       st.close();
       conn.close();
       return suppliersList;
       }
       
       
       public ObservableList<PieChart.Data> getOrderStatusPercentage() throws SQLException{ //Used to return pie chart slices to display percentage of orders.
       Connection conn=DriverManager.getConnection("jdbc:sqlite:database.db");
       Statement st= conn.createStatement();
       String query= "SELECT COUNT(STATUS) AS ORDER_PLACED FROM ORDERS WHERE STATUS='Order Placed';";
       String query2= "SELECT COUNT(STATUS) AS PROCESSING FROM ORDERS WHERE STATUS='Processing';";
       String query3="SELECT COUNT(STATUS) AS SHIPPED FROM ORDERS WHERE STATUS='Shipped';";
       ResultSet rs= st.executeQuery(query);
       ObservableList<PieChart.Data> statusList= FXCollections.observableArrayList();
       while(rs.next()){
           statusList.add(new PieChart.Data("Order Placed",rs.getInt("ORDER_PLACED")));
           
       }
       ResultSet rs2= st.executeQuery(query2);
       while(rs2.next()){
           statusList.add(new PieChart.Data("Processing", rs.getInt("PROCESSING")));
          
       }
       ResultSet rs3= st.executeQuery(query3);
       while(rs3.next()){
            statusList.add(new PieChart.Data("Shipped", rs.getInt("SHIPPED")));
       }
       st.close();
       conn.close();
       return statusList;
  
        
}
}
    

