package au.edu.unsw.business.infs2605.fxstarterkit;

import java.io.IOException;
import java.sql.SQLException;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;    

public class LoginController {
   
    
    @FXML
    public Button next, login;
    @FXML
    public AnchorPane anchorpane;
    @FXML
    public PasswordField password;
    @FXML
    public TextField username;
    @FXML
    public Label title;
    @FXML
    public Label message;
    
    Database database=new Database(); 
    private String [] employee_supplier_id= new String[1];
   
   
    @FXML
    private void switchToHome() throws IOException {
        App.setRoot("Home");
    }
    @FXML
    private void handleLoginButtonAction() throws IOException, SQLException, ClassNotFoundException{ //Handles Login by taking user input from user and sending it to a login method in the database to find if user exists in the USER database table
        String username_text= username.getText();
        String password_text= password.getText();     
        if(database.login(username_text, password_text).equals("store manager")){ // the login method in the Database class returns a string based on if the user input matches rows in the user table. If it returns sotremanager than we allow it to progress
            message.setText("Login Successful");
            message.setFont(Font.font("Verdana", FontWeight.BOLD, 10));
            next.setVisible(true); //make next button visible
        }
        else if(!database.login(username_text, password_text).equals("none") && !database.login(username_text, password_text).equals("store manager") ){ //if the login method returns a variable other than none or storemanager than we know it has to be the supplier_id
            message.setText("Login Successful!");
            message.setFont(Font.font("Verdana", FontWeight.BOLD, 10));
            employee_supplier_id[0]=database.login(username_text, password_text); //we add the supplier id to an arraylist called employee_supplier_id.
            next.setVisible(true); // make the next button visible to user.
        
          
        }
        else if(database.login(username_text, password_text).equals("none")){
            message.setText("Incorrect Username or Password!");
            message.setFont(Font.font("Verdana", FontWeight.BOLD, 10));
       
   }
    }
    @FXML
    public void handleNextButton() throws IOException{
        EmployeeSupplier.setArray(employee_supplier_id); //adds the array employee_supplier_id to the EmployeeSupplier class in which the setter method setArray is used to store an instance of the array. This is because the method is static
        switchToHome(); //This is important because when we switch scenes without the EmployeeSupplier class the instance of Array will be lost.
        
    }
    @FXML
    protected void initialize() throws ClassNotFoundException, SQLException {
        // What should the user see when the screen loads?
        message.setText(" ");
        next.setVisible(false);
    
}
    }

