/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package au.edu.unsw.business.infs2605.fxstarterkit;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;


/**
 *
 * @author ama32
 */
public class HomeController {
    @FXML
    TableView orders;
    @FXML
    Button Home;
    @FXML
    Button createorder;
    @FXML
    Button logoff;
    @FXML
    Button updateorder;
    @FXML
    Button deleteorder;
    @FXML
    Button refreshPieChart;
    @FXML
    Button addproduct;
    @FXML
    Button about;
    @FXML
    Button supplier;
    
    @FXML
    TableColumn<Orders, String> order_id;
    @FXML
    TableColumn<Orders, String> product_id;
    @FXML
    TableColumn<Orders, String> supplier_id;
    @FXML 
    TableColumn<Orders, Integer> quantity;
    @FXML
    TableColumn<Orders, String> status;
    @FXML
    TableColumn<Orders, String> order_timestamp;
    @FXML
    TableColumn<Orders, String> product_name;
    @FXML
    TableColumn<Orders, Double> total_price;
    @FXML
    TextField order_idInput;
    @FXML
    TextField product_idInput; 
    @FXML
    TextField supplier_idInput;
    @FXML
    TextField quantityInput;
    @FXML
    TextField statusInput;
    @FXML
    TextField search;
    @FXML
    PieChart piechart;
    
    int index= -1;
            
    Database database= new Database();
    ObservableList<Orders> ordersList= FXCollections.observableArrayList();
    ObservableList<PieChart.Data> statusList= FXCollections.observableArrayList(); //observable list for piechart data
      
    
  //Following methods are used to change scenes
    private void switchtoLogin() throws IOException{
        App.setRoot("Login");
    }
    @FXML
    public void handleLoggOffButton() throws IOException{
         EmployeeSupplier.falseUserAvailable();
         switchtoLogin();
        }
        
    private void switchtoSupplier() throws IOException{
        App.setRoot("Supplier");
    }
    @FXML
    public void handleSupplierButton() throws IOException{
        switchtoSupplier();
    }
    
    private void switchtoAbout() throws IOException{
        App.setRoot("About");
    }
    @FXML
    public void handleAboutButton() throws IOException{
        switchtoAbout();
    }
    @FXML
    private void switchtoHome() throws IOException{
        App.setRoot("Home");
    }
    @FXML
    public void handleHomeButton() throws IOException{
       String[] arraytest= new String[1];
       arraytest= EmployeeSupplier.getArray();
      if(arraytest!=null){
            
        }
      else {
        switchtoHome();
    }
    }
    public String getEmployee_id(String employee_id){
        return employee_id;
    }
    @FXML
    public void initialize() throws SQLException, IOException, ClassNotFoundException{
        // Create the TableView. We utilised the EmployeeSupplier class as a kind of middle man which stores the supplier id if the user is of Supplier Type. This is  so it can then be used to filter the data out to return only orders for a certain suplier
        String[] employee_supplier_id= new String[1];
    if(EmployeeSupplier.isUserAvailable()) employee_supplier_id = EmployeeSupplier.getArray(); // returns the supplier id inside an array and applies it to a new Array local to this controller. The If statement is used to check if the User is new or not. If the user is logged in it will be UserAvailable=true
        if(employee_supplier_id[0]!=null) { //If supplier_id exits send it to getOrdersforSupplierUser method to filter table and return observable list
        ordersList= database.getOrdersforSupplierUser(employee_supplier_id[0]);
        orders.setItems(ordersList);
        order_id.setCellValueFactory(new PropertyValueFactory<>("order_id"));
        product_id.setCellValueFactory(new PropertyValueFactory<>("product_id"));
        supplier_id.setCellValueFactory(new PropertyValueFactory<>("supplier_id"));
        quantity.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        status.setCellValueFactory(new PropertyValueFactory<>("status"));
        order_timestamp.setCellValueFactory(new PropertyValueFactory<>("order_timestamp"));
        product_name.setCellValueFactory(new PropertyValueFactory<>("product_name"));
        total_price.setCellValueFactory(new PropertyValueFactory<>("total_price"));
        orders.setEditable(true);
        createorder.setVisible(false);
        addproduct.setVisible(false);
        deleteorder.setVisible(false);
        
        }
        else{
        ordersList= database.getOrders();
        orders.setItems(ordersList);
        order_id.setCellValueFactory(new PropertyValueFactory<>("order_id"));
        product_id.setCellValueFactory(new PropertyValueFactory<>("product_id"));
        supplier_id.setCellValueFactory(new PropertyValueFactory<>("supplier_id"));
        quantity.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        status.setCellValueFactory(new PropertyValueFactory<>("status"));
        order_timestamp.setCellValueFactory(new PropertyValueFactory<>("order_timestamp"));
        product_name.setCellValueFactory(new PropertyValueFactory<>("product_name"));
        total_price.setCellValueFactory(new PropertyValueFactory<>("total_price"));
        orders.setEditable(true);
        }
        
        //Creating Filtered List to create search functionality for Orders Tableview in the form of a new textfield above the table.
        FilteredList<Orders> filteredData= new FilteredList(ordersList,p-> true);
        search.textProperty().addListener((observable, oldValue, newValue) -> {
			filteredData.setPredicate(Orders -> {
				// If filter text is empty, display all Products/entries in the database.
				if (newValue == null || newValue.isEmpty()) {
					return true;
				}
				
				
				String lowerCaseFilter = newValue.toLowerCase();
				
				if (Orders.getProduct_name().toLowerCase().contains(lowerCaseFilter)) {
					return true; // Filter matches product name
				} else if(Orders.getStatus().toLowerCase().contains(lowerCaseFilter)){
                                        return true; // Filter matches order status
                                }
				return false; // Does not match.
			});
		});
		
		// Wrap the FilteredList in a SortedList. 
		SortedList<Orders> sortedData = new SortedList<>(filteredData);
		
		// Bind the SortedList comparator to the TableView comparator.
		sortedData.comparatorProperty().bind(orders.comparatorProperty());
		
		// Add sorted (and filtered) data to the table.
		orders.setItems(sortedData);
                
                // Creating a pie chart
                statusList= database.getOrderStatusPercentage();
                piechart.setData(statusList);
                piechart.setTitle("Status of Orders");
                
    }
                
    @FXML
    public void getSelected(MouseEvent event){ // used to set text of the textfields when clicking on an entry of the table.
    index= orders.getSelectionModel().getSelectedIndex();
    if(index<=-1){
        
        return;
    }
    order_idInput.setText(order_id.getCellData(index).toString());
    supplier_idInput.setText(supplier_id.getCellData(index).toString());
    product_idInput.setText(product_id.getCellData(index).toString());
    quantityInput.setText(quantity.getCellData(index).toString());
    statusInput.setText(status.getCellData(index).toString());
    
    
    
}
    @FXML
    public void handleRefresh() throws SQLException{  //method is used to refresh the table once a new order is created, edited, deleted or a new product is added to existing order
      String[] employee_supplier_id= new String[1];
    if(EmployeeSupplier.isUserAvailable()) employee_supplier_id = EmployeeSupplier.getArray();
        if(employee_supplier_id[0]!=null) {
        ordersList= database.getOrdersforSupplierUser(employee_supplier_id[0]);
        orders.setItems(ordersList);
        order_id.setCellValueFactory(new PropertyValueFactory<>("order_id"));
        product_id.setCellValueFactory(new PropertyValueFactory<>("product_id"));
        supplier_id.setCellValueFactory(new PropertyValueFactory<>("supplier_id"));
        quantity.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        status.setCellValueFactory(new PropertyValueFactory<>("status"));
        order_timestamp.setCellValueFactory(new PropertyValueFactory<>("order_timestamp"));
        product_name.setCellValueFactory(new PropertyValueFactory<>("product_name"));
        total_price.setCellValueFactory(new PropertyValueFactory<>("total_price"));
        orders.setEditable(true);
        createorder.setVisible(false);
        addproduct.setVisible(false);
        deleteorder.setVisible(false);
        
        }
        else{
        ordersList= database.getOrders();
        orders.setItems(ordersList);
        order_id.setCellValueFactory(new PropertyValueFactory<>("order_id"));
        product_id.setCellValueFactory(new PropertyValueFactory<>("product_id"));
        supplier_id.setCellValueFactory(new PropertyValueFactory<>("supplier_id"));
        quantity.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        status.setCellValueFactory(new PropertyValueFactory<>("status"));
        order_timestamp.setCellValueFactory(new PropertyValueFactory<>("order_timestamp"));
        product_name.setCellValueFactory(new PropertyValueFactory<>("product_name"));
        total_price.setCellValueFactory(new PropertyValueFactory<>("total_price"));
        orders.setEditable(true);
        }
    }
    @FXML
    public void handleCreateOrder() throws SQLException{ //Creates new order. Works by collecting user input to then apply an SQL query
        String order_id= order_idInput.getText();
        String product_id= product_idInput.getText();
        String supplier_id= supplier_idInput.getText();
        int quantity= Integer.parseInt(quantityInput.getText());
        String status= statusInput.getText();
        Connection conn= DriverManager.getConnection("jdbc:sqlite:database.db");
       PreparedStatement ps= conn.prepareStatement("INSERT INTO ORDERS (ORDER_ID, STATUS) "
       + "VALUES(?, 'Order Placed');"); // we split the Orders into two table Orders and Order Product. Orders just has Order_id and Status whereas orderproduct has everything. This is to address the pie chart functionality of seeing percentage of order status
       ps.setString(1, order_id);
       ps.executeUpdate();
       ps.close();
      PreparedStatement ps2= conn.prepareStatement("INSERT INTO ORDERPRODUCT (ORDER_ID, PRODUCT_ID, SUPPLIER_ID, QUANTITY, ORDER_TIMESTAMP) "
       + "VALUES(?, ?, ?, ?, ?);");
       ps2.setString(1, order_id);
       ps2.setString(2, product_id);
       ps2.setString(3, supplier_id);
       ps2.setInt(4, quantity);
       ps2.setString(5, new java.sql.Timestamp(new java.util.Date().getTime()).toString()); // to create Time stamp we used the following ocmmand
       ps2.executeUpdate();
       ps2.close();
       conn.close();
       handleRefresh();
    }
    @FXML
    public void handleAddProductToOrderButton() throws SQLException{ //Adds new product to existing order
      String order_id= order_idInput.getText();
        String product_id= product_idInput.getText();
        String supplier_id= supplier_idInput.getText();
        int quantity= Integer.parseInt(quantityInput.getText());
        String status= statusInput.getText();
        Connection conn= DriverManager.getConnection("jdbc:sqlite:database.db");
      PreparedStatement ps= conn.prepareStatement("INSERT INTO ORDERPRODUCT (ORDER_ID, PRODUCT_ID, SUPPLIER_ID, QUANTITY, ORDER_TIMESTAMP) " //only adds to ORDERPRODUCT and not Orders because if we do so it will duplicate the status field which is not what we want when fetching status for pie chart
       + "VALUES(?, ?, ?, ?, ?);");
       ps.setString(1, order_id);
       ps.setString(2, product_id);
       ps.setString(3, supplier_id);
       ps.setInt(4, quantity);
       ps.setString(5, new java.sql.Timestamp(new java.util.Date().getTime()).toString());
       ps.executeUpdate();
       ps.close();
       conn.close();
       handleRefresh();
      
  }
    @FXML
    public void handleUpdateOrderButton() throws SQLException{ //Updates order
        String order_id= order_idInput.getText();
        String product_id= product_idInput.getText();
        String supplier_id= supplier_idInput.getText();
        int quantity= Integer.parseInt(quantityInput.getText());
        String status= statusInput.getText();
        Connection conn= DriverManager.getConnection("jdbc:sqlite:database.db");
        PreparedStatement ps=conn.prepareStatement("UPDATE ORDERS SET STATUS=? WHERE ORDER_ID=?");
        ps.setString(1, status);
        ps.setString(2, order_id);
        ps.executeUpdate();
        ps.close();
        PreparedStatement ps2= conn.prepareStatement("UPDATE ORDERPRODUCT SET QUANTITY=? WHERE ORDER_ID=? AND PRODUCT_ID=? AND SUPPLIER_ID=?;");
        ps2.setInt(1, quantity);
        ps2.setString(2, order_id);
        ps2.setString(3, product_id);
        ps2.setString(4, supplier_id);
        ps2.executeUpdate();
        ps2.close();
        conn.close();
        handleRefresh();
        
    }
    public void handleDeleteOrderButton() throws SQLException{ //Deletes order
        String order_id= order_idInput.getText();
        String product_id= product_idInput.getText();
        String supplier_id= supplier_idInput.getText();
        Connection conn= DriverManager.getConnection("jdbc:sqlite:database.db");
        PreparedStatement ps= conn.prepareStatement("DELETE FROM ORDERS WHERE ORDER_ID=?");
        ps.setString(1, order_id);
        ps.executeUpdate();
        ps.close();
        PreparedStatement ps2= conn.prepareStatement("DELETE FROM ORDERPRODUCT WHERE ORDER_ID=? ");
        ps2.setString(1, order_id);
        ps2.executeUpdate();
        ps2.close();
        conn.close();
        handleRefresh();
    }
   
    public void handleRefreshPieChartButton() throws SQLException{ //refreshes pie chart through a button
                statusList= database.getOrderStatusPercentage();
                piechart.setData(statusList);
                piechart.setTitle("Status of Orders");
    }
    }
