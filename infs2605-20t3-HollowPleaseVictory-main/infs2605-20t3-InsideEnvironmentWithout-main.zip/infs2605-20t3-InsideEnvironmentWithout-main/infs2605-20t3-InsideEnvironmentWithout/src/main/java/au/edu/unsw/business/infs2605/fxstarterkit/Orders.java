/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package au.edu.unsw.business.infs2605.fxstarterkit;
import java.util.*;
/**
 *
 * @author ama32
 */
public class Orders {
    private String order_id;
    private String product_id;
    private String supplier_id;
    private Integer quantity;
    private String status;
    private String order_timestamp;
    private String product_name;
    private Double total_price;

    public Orders(String order_id, String product_id, String supplier_id, Integer quantity, String status, String order_timestamp, String product_name, Double total_price) {
        this.order_id = order_id;
        this.product_id = product_id;
        this.supplier_id = supplier_id;
        this.quantity = quantity;
        this.status = status;
        this.order_timestamp = order_timestamp;
        this.product_name = product_name;
        this.total_price=total_price;
    }

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public String getProduct_id() {
        return product_id;
    }

    public void setProduct_id(String product_id) {
        this.product_id = product_id;
    }

    public String getSupplier_id() {
        return supplier_id;
    }

    public void setSupplier_id(String supplier_id) {
        this.supplier_id = supplier_id;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getOrder_timestamp() {
        return order_timestamp;
    }

    public void setOrder_timestamp(String order_timestamp) {
        this.order_timestamp = order_timestamp;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public Double getTotal_price() {
        return total_price;
    }

    public void setTotal_price(Double total_price) {
        this.total_price = total_price;
    }

    
    
}
