/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package au.edu.unsw.business.infs2605.fxstarterkit;

/**
 *
 * @author ama32
 */
public class EmployeeSupplier {
    private static boolean userAvailable = false; //If user is logged this is true
    private static String[] array; // the array that is passed from login controller to here.
    
  public static boolean isUserAvailable() {
        return userAvailable;
  }

    public static void setArray(String[] array) {
        EmployeeSupplier.array = array; //pass login controller array to here
        userAvailable=true; //set the user avaiability to true
    }
     public static String[] getArray() {
        return array;
    }

    public static void falseUserAvailable(){
        userAvailable=false; //used when user clicks on log out button in all pages. Used to reset the boolean to false. This is to reset all the data so that when the app user tries to switch accounts it will work.
    }
   
}
