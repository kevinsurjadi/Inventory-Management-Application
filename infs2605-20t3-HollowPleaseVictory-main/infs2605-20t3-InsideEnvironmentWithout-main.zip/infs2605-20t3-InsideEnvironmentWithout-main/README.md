# infs2605-20t3-InsideEnvironmentWithout
infs2605-20t3-InsideEnvironmentWithout

The Application Should Run Correctly at 900x600 dimensions not fullscreen.

## Login 

### Store manager login
In order to login please use:

**username: storemanager1**

**password: 1234**

or
**username: storemanager2**

**password:5678**

### Supplier User (AF1)

Each supplier user corresponds to a specific supplier ID. This is because we introduced an employee_id in the supplier table for each entry of supplier.
so for Supplier Employee 1 login is:

**username: supplier1**

**password: 1234**


**supplier 2 is:**

**username: supplier2**

**password:1234**
 
 and vice versa
 hence logging in using supplier1 login for example, should only display orders from first supplier which is all rows in the tableview with SPO1 in Supplier_ID column and vice versa for supplier 2 displaying SPO2 orders only etc.
 
 ## Orders and Suppliers 
 
 When adding a new Supplier to the App through the supplier page you will need to input an "employee_id" as well.

 **The app currently only has 4 supplier users created currently in the system
  so you can use supplier1 - supplier 4 to login**
 

 When creating a New Order, there are 8 products that can be ordered. The product_id field for them is **P01-P08**
 
 When creating a New Order, Order ID syntax is O0[insert number] i.e. O01, O02, O03, O04
 
 When creating a New Order, Supplier ID syntax is SP0[insert number] i.e. SP01, SP02, SP03. 
 
 In the Database there is only SP01-SP04 suppliers right now. Although you can create more in the Supplier Page.

 On default on order creation the order will be created with order placed status. Even if you type something into the status field it will still be placed as order placed.
 The Status of Orders can be set to 3 states: "Order Placed", "Processing" and "Shipped". 
 
**If You want to add more than one product to an order (AF2): fill in the order details and press the Add Product to Existing Order Button.**

**When Updating orders you can only update the quantity and status fields only. You can't update ORDER_ID, PRODUCT_ID OR SUPPLIER_ID. Only way to do so is to either create a new   order or delete exisitng order.**

 The TableView on the Homepage is also interactive, clicking on it should change the textfields underneath it.

 The Search Functionality in the Homepage allows the user to search via Product Name or Status of Order.
 
 
