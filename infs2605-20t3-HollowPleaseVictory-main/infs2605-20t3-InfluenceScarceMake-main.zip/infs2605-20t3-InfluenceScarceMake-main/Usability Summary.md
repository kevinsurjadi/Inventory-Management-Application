#1. Visibility of system status
Providing communication and transparency between the user and the application allows the user to make better decisions by adding information. Therefore, provide appropriate and timely feedback to the users so that they are aware of what is happening. When a user enters an incorrect username and password, an error message appears, giving the user feedback that they have made a mistake and the location of the error.

#2. Match between system and the real world
The application should use the user's language, making use of real-world vocabulary, concepts, and conventions. Therefore, information should appear in a logical and natural order so that users can find comfort in familiarity. A pie chart is a good design for matching a system to the real world.

#3. User control and freedom
It is very important to provide users with an option to correct errors and, therefore, provide clearly marked Undo, Redo, and Exit. Users can re-enter and correct errors in their username and password, and users can also delete Orders.

#4. Consistency and standards
Ensure that the platform connects through consistent actions, contexts, and words. The application follows a consistent layout on every page, giving the application a uniform look and feel to avoid user confusion. Each page follows a consistent layout and design, with colors, fonts, and sizes being consistent throughout the application, creating a clean look and feel.

#5. Error prevention
While error messages are essential, a good design will consider careful planning to prevent problems from occurring and to communicate errors in a clear, actionable, and elegant manner. This is done by eliminating error-prone conditions or checking for errors before users make them. There are two parts: slippage errors and errors, and an effective design will consider the risks and implications of both. For example, when adding an Order Product, the user can choose to select the existing Product ID and Supplier ID instead of filling them in manually, which prevents errors.

#6. Recognition rather than recall
Focus on minimizing the user's memory load, as the user should not be required to remember information from one part of the conversation to another. Therefore, recognition rather than memory is facilitated by making objects, actions, and options visible to facilitate decision making. The use of navigation tabs helps users access any area of the application they are looking for, rather than having to recall locations.

#7. Flexibility and efficiency of use
The system can meet the needs of both experienced and inexperienced users, utilizing shortcuts, advanced tools, and frequent operations. The system uses simple language and clear buttons to assist inexperienced users and improve ease of use.

#8. Aesthetic and minimalist design
When irrelevant information is publicly displayed, the relevance of important elements is diminished. Essentially, each additional unit of information will compete with the relevant information, reducing its visibility overall. A cohesive, minimalist design is integrated into all pages of InventorySystem to ensure that users can easily navigate the application with an aesthetically pleasing design. The application simply displays the necessary content on each page. This avoids confusing the user with unnecessary images or overly complex layouts. The application uses appropriately sized fonts to make navigation through the application as simple and comfortable as possible.

#9. Help users recognize, diagnose, and recover from errors
The Inventory System includes specific error messages to clearly alert users to the errors they have made. These messages are created in simple language to help any user identify the errors they have made, regardless of their technical experience.

#10. Help and documentation
While it is preferable for a system to be able to be used without documentation, it is always necessary to provide useful documentation to facilitate finding and searching for information. ReadMe files include help and usability information that users need the first time they apply an application.Read Me documentation includes help and usability information that users will need when they first apply the application. It helps users identify, diagnose, and troubleshoot errors.
