# Instructions of the App

Run the App.java, you will see the login screen as below

<figure>
    <img src="imgs/login.png">
</figure>

By default, you can login with the following three accounts
 * username: John, password: John (employee of the supplier 1)
 * username: Mike, password: Mike (employee of the supplier 2)
 * username: Amelia, password: Amelia (employee of the supplier 3)


 The incorrect combination of the username and password should not allow the user to access other screens and will prompt “Sorry incorrect credentials.” at the bottom left.(UM)

 <figure>
    <img src="imgs/logerror.png">
 </figure>


 After login, you can see a navigation bar complied with Supplier View, Order View, Order Stats and About. On “Supplier View” screen, you can add Supplier ID, Supplier Name, Address, Phone Number at the bottom.

<figure>
        <img src="imgs/supplierview.png">
</figure>

The employee can only edit order status that their supplier participated. (AF1)
An order can have multiple products from multiple suppliers with different quantity. (AF2)

<figure>
        <img src="imgs/orderview.png">
</figure>

On “Order Stats” screen, you can see a pie chart to show an overview of the order status. You can use the search bar on the right-hand side to search orders for a particular product name, or for all orders in a particular status. 

<figure>
        <img src="imgs/orderstats.PNG">
</figure>

All resources from any third-party were included in “About” screen.
<figure>
        <img src="imgs/about.png">
</figure>
