package com.unsw.midtermprojectinventorysystem.models;
public class Product {

    private int productId;

    private String productName;

    private float price;

    private String productType;

    public Product(){

    }

    public Product(int productId, String productName, float price, String productType){
        this.productId = productId;
        this.productName = productName;
        this.price = price;
        this.productType = productType;
    }

    public void setProductId(int productId){
        this.productId = productId;
    }

    public void setProductName(String productName){
        this.productName = productName;
    }

    public void setPrice(float price){
        this.price = price;
    }

    public void setProductType(String productType){
        this.productType = productType;
    }

    public int getProductId(){
        return this.productId;
    }

    public String getProductName(){
        return this.productName;
    }

    public float getPrice(){
        return this.price;
    }

    public String getProductType(){
        return this.productType;
    }
}
