package com.unsw.midtermprojectinventorysystem.controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;

import java.io.IOException;
import com.unsw.midtermprojectinventorysystem.App;

public class HomeController {

    @FXML
    TabPane tabPane;

    @FXML
    Tab supplierViewPage;

    @FXML
    Tab orderViewPage;

    @FXML
    Tab orderStatsPage;

    @FXML
    Tab aboutPage;

    @FXML
    public void initialize() throws IOException {
        supplierViewPage.setContent(new FXMLLoader(App.class.getResource("supplierPage.fxml")).load());
        orderViewPage.setContent(new FXMLLoader(App.class.getResource("orderPage.fxml")).load());
        orderStatsPage.setContent(new FXMLLoader(App.class.getResource("orderStatsPage.fxml")).load());
        aboutPage.setContent(new FXMLLoader(App.class.getResource("about.fxml")).load());
    }

}
