package com.unsw.midtermprojectinventorysystem.controllers;

import javafx.fxml.FXML;

public class AboutController {

    @FXML
    public void initialize(){

    }
}
