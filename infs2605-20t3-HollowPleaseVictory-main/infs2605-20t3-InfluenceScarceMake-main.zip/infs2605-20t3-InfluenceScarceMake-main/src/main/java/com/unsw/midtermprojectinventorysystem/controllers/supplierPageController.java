package com.unsw.midtermprojectinventorysystem.controllers;

import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import com.unsw.midtermprojectinventorysystem.heplers.DatabaseManager;
import com.unsw.midtermprojectinventorysystem.models.Supplier;
import java.sql.SQLException;
import java.util.ArrayList;

public class supplierPageController {

    @FXML
    TableView<Supplier> supplierView;

    @FXML
    TextField supplierId;

    @FXML
    TextField supplierName;

    @FXML
    TextField address;

    @FXML
    TextField phoneNumber;

    @FXML
    TableColumn<Supplier, String> colSupplierName;

    @FXML
    TableColumn<Supplier, String> colSupplierAddress;

    @FXML
    TableColumn<Supplier, String> colSupplierPhone;

    @FXML
    public void initialize() throws SQLException {
        colSupplierName.setCellValueFactory(new PropertyValueFactory<>("supplierName"));
        colSupplierAddress.setCellValueFactory(new PropertyValueFactory<>("address"));
        colSupplierPhone.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));

        colSupplierName.setCellFactory(TextFieldTableCell.forTableColumn());
        colSupplierAddress.setCellFactory(TextFieldTableCell.forTableColumn());
        colSupplierPhone.setCellFactory(TextFieldTableCell.forTableColumn());
        supplierView.setEditable(true);

        colSupplierName.setOnEditCommit(e->{
            e.getTableView().getItems().get(e.getTablePosition().getRow()).setSupplierName(e.getNewValue());
            Supplier supplier = e.getTableView().getItems().get(e.getTablePosition().getRow());
            try {
                DatabaseManager.updateSupplier(supplier);
            } catch (SQLException exception) {
                exception.printStackTrace();
            }
        });
        colSupplierAddress.setOnEditCommit(e->{
            e.getTableView().getItems().get(e.getTablePosition().getRow()).setAddress(e.getNewValue());
            Supplier supplier = e.getTableView().getItems().get(e.getTablePosition().getRow());
            try {
                DatabaseManager.updateSupplier(supplier);
            } catch (SQLException exception) {
                exception.printStackTrace();
            }
        });
        colSupplierPhone.setOnEditCommit(e->{
            e.getTableView().getItems().get(e.getTablePosition().getRow()).setPhoneNumber(e.getNewValue());
            Supplier supplier = e.getTableView().getItems().get(e.getTablePosition().getRow());
            try {
                DatabaseManager.updateSupplier(supplier);
            } catch (SQLException exception) {
                exception.printStackTrace();
            }
        });

        ObservableList<Supplier> data = supplierView.getItems();
        ArrayList<Supplier> suppliers = DatabaseManager.fetchAllSuppliers();
        data.addAll(suppliers);
        supplierView.setItems(data);
    }

    @FXML
    public void addSupplier() throws SQLException {
        String addSupplierId = supplierId.getText();
        String addSupplierName = supplierName.getText();
        String addSupplierAddress = address.getText();
        String addSupplierPhone = phoneNumber.getText();
        Supplier supplier = new Supplier(addSupplierId, addSupplierName, addSupplierPhone, addSupplierAddress);
        DatabaseManager.addSupplier(supplier);
        // update supplier list view
        ObservableList<Supplier> data = supplierView.getItems();
        data.add(supplier);
        supplierView.setItems(data);

        // clean text fields
        supplierId.clear();
        supplierName.clear();
        address.clear();
        phoneNumber.clear();
    }
}
