package com.unsw.midtermprojectinventorysystem.models;

public class Store {

    private int storeId;

    private String address;

    private String phoneNumber;

    private int storeManager;

    public Store(){

    }

    public Store(int storeId, String address, String phoneNumber, int storeManager){
        this.storeId = storeId;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.storeManager = storeManager;
    }

    public void setStoreId(int storeId){
        this.storeId = storeId;
    }

    public void setAddress(String address){
        this.address = address;
    }

    public void setPhoneNumber(String phoneNumber){
        this.phoneNumber = phoneNumber;
    }

    public void setStoreManager(int storeManager){
        this.storeManager = storeManager;
    }

    public int getStoreId(){
        return this.storeId;
    }

    public String getAddress(){
        return this.address;
    }

    public String getPhoneNumber(){
        return this.phoneNumber;
    }

    public int getStoreManager(){
        return this.storeManager;
    }
}
