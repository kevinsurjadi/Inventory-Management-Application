# Project arrangement


## 
According to requirements, we allocated tasks into four parts.
* Databse(2 Days)
    * Database and ERD design -- YAO YIN & XUANYE HE
    * Database population
    * Models(java class --> database table)

* App Design
  * Login Screen & About -- XUANYE HE
  * Table View(SupplierView/OrderView) -- HAIFAN LIN & JIAN WANG
  * OrderStats(Pie/Search) -- JIAN WANG

Development process
* After dividing tasks, 4 group members develop on their own part simultaneously.
* We use WeChat to communicate and share codes.
* After finishing everyone's part, we use zoom to debug the project.  (1 member to share screen, others can view the screen and share opinions.)
* After debugging the project, everyone upload their part's code to github.