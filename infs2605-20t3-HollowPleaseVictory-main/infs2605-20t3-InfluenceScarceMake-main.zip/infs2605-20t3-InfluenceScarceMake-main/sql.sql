-- create tables

CREATE TABLE User(
`user_id` integer primary key autoincrement,
`username` varchar(32),
`password` varchar(512),
`full_name` varchar(64)
);

INSERT INTO User(`username`, `password`, `full_name`) VALUES('John', '$2a$10$afnmgPI5Rbdjc5ChnQujgORDX9BqbgR/tUinrANUiUiAzCUlVTav6', 'John Smith');
INSERT INTO User(`username`, `password`, `full_name`) VALUES('Mike', '$2a$10$HfqPlHJWSWUuaugM.V2k6u2H.l7iKX22lg6lfgGVO867elMslcIiG', 'Mike Smith');
INSERT INTO User(`username`, `password`, `full_name`) VALUES('Amelia', '$2a$10$HCn33WWMcyZBTNLAya9O7etWkWgNTfXBn5CqGv8CjIujFb3ubojLi', 'Amelia Smith');


CREATE TABLE Store(
`store_id` integer primary key autoincrement,
`address` varchar(256),
`phone_number` varchar(16),
`store_manager` integer,
foreign key(store_manager) references User(user_id)
);

INSERT INTO Store(`address`, `phone_number`, `store_manager`) VALUES('ABC Street No.168', '673134', 1);
INSERT INTO Store(`address`, `phone_number`, `store_manager`) VALUES('DEF Street No.168', '673135', 2);
INSERT INTO Store(`address`, `phone_number`, `store_manager`) VALUES('Alpha Street No.168', '673136', 3);


CREATE TABLE Product(
`product_id` integer primary key autoincrement,
`product_name` varchar(64),
`price` float,
`product_type` varchar(32)
);

INSERT INTO Product(`product_name`, `price`, `product_type`) VALUES('Apple', 12.88, 'Fruit');
INSERT INTO Product(`product_name`, `price`, `product_type`) VALUES('Orange', 18.88, 'Fruit');
INSERT INTO Product(`product_name`, `price`, `product_type`) VALUES('Chicken', 12.88, 'Meal');
INSERT INTO Product(`product_name`, `price`, `product_type`) VALUES('TV', 12.88, 'HouseAppliance');
INSERT INTO Product(`product_name`, `price`, `product_type`) VALUES('AirConditioner', 12.88, 'HouseAppliance');


CREATE TABLE Supplier(
`supplier_id` integer primary key autoincrement,
`supplier_name` varchar(64),
`phone_number` varchar(16),
`address` varchar(128)
);

INSERT INTO Supplier(`supplier_name`, `phone_number`, `address`) VALUES('Alpha', '34333', 'PA Street No.666');
INSERT INTO Supplier(`supplier_name`, `phone_number`, `address`) VALUES('Beta', '35333', 'PB Street No.666');
INSERT INTO Supplier(`supplier_name`, `phone_number`, `address`) VALUES('Gamma', '36333', 'PG Street No.666');


CREATE TABLE `Order`(
`order_id` integer primary key autoincrement,
`status` varchar(32),
`order_timestamp` timestamp
);

CREATE TABLE OrderProduct(
`order_id` integer,
`product_id` integer,
`supplier_id` integer,
`quantity` int,
primary key(`order_id`, `product_id`, `supplier_id`),
foreign key(`order_id`) references `Order`(`order_id`) on delete cascade,
foreign key(`product_id`) references Product(`product_id`),
foreign key(`supplier_id`) references Supplier(`supplier_id`)
);

CREATE TABLE OrderStatusUpdate(
`update_id` integer primary key autoincrement,
`order_id` integer,
`status` varchar(32),
`update_timestamp` timestamp,
`update_user` int,
foreign key(`order_id`) references `Order`(`order_id`) on delete cascade,
foreign key(`update_user`) references User(`user_id`)
);

CREATE TABLE SupplierEmployee(
`supplier_id` integer,
`employee_id` integer,
primary key(`supplier_id`, `employee_id`),
foreign key(`supplier_id`) references Supplier(`supplier_id`),
foreign key(`employee_id`) references User(`user_id`) on delete cascade
);

INSERT INTO SupplierEmployee VALUES(1, 1);
INSERT INTO SupplierEmployee VALUES(2, 2);
INSERT INTO SupplierEmployee VALUES(3, 3);

