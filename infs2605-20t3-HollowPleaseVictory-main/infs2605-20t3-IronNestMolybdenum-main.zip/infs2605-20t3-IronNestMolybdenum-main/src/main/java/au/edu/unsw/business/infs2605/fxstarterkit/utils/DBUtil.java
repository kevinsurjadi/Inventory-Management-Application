package au.edu.unsw.business.infs2605.fxstarterkit.utils;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DBUtil {
    public static Connection createConnection() {
        Connection connection = null;
        try {
            Class.forName("org.sqlite.JDBC");
            File dir=new File("db");
            if(!dir.exists()){
                dir.mkdirs();
            }
            connection = DriverManager.getConnection("jdbc:sqlite:db/OrderSystem.db");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return connection;
    }

    public static void initDB(boolean rebuild){
        if (rebuild || !new File("db/OrderSystem.db").exists()){
            Connection conn = createConnection();
            try {
                Statement smt = conn.createStatement();
                for(String tabName:SQL.TableNames){
                    if(rebuild){
                        System.out.println(SQL.dropTableSQL(tabName));
                        smt.executeUpdate(SQL.dropTableSQL(tabName));
                    }
                    System.out.println(SQL.createTableSQL(tabName));
                    smt.executeUpdate(SQL.createTableSQL(tabName));
                }
                smt.executeUpdate("insert into user(userName,password,fullName) values('admin','admin','admin');");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

    }

}
