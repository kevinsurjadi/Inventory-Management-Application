package au.edu.unsw.business.infs2605.fxstarterkit.dao;

import au.edu.unsw.business.infs2605.fxstarterkit.models.Order;
import au.edu.unsw.business.infs2605.fxstarterkit.models.Store;
import au.edu.unsw.business.infs2605.fxstarterkit.models.Supplier;
import au.edu.unsw.business.infs2605.fxstarterkit.models.User;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.DBUtil;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.DateUtil;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.SQL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class SupplierDao extends BaseDao<Supplier> {

    private static SupplierDao supplierDao=new SupplierDao();

    private SupplierDao(){}

    public static SupplierDao getSupplierDao(){
        return supplierDao;
    }

    @Override
    public void deleteById(int id) {
        this.delete(findById(id));
    }

    @Override
    public void delete(Supplier supplier) {
        List<User> users = supplier.getUsers();
        for(User u:users){
            UserDao.getUserDao().delete(u);
        }
        for(Order o:supplier.getOrders()){
            OrderDao.getOrderDao().delete(o);
        }
        super.deleteById(supplier.getId());
    }

    @Override
    public void save(Supplier supplier) {
        if (supplier.getId() > 0)
            this.update(supplier);
        else {
            try (Connection connection = DBUtil.createConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement(SQL.InsertSupplierSQL)) {

                preparedStatement.setString(1, supplier.getAddress());
                preparedStatement.setString(2, supplier.getPhoneNumber());
                preparedStatement.setString(3, supplier.getSupplierName());

                preparedStatement.executeUpdate();

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void update(Supplier supplier) {
        try (Connection connection = DBUtil.createConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SQL.UpdateSupplierSQL)) {
            preparedStatement.setString(1, DateUtil.date2Str(new java.util.Date()));
            preparedStatement.setString(2, supplier.getAddress());
            preparedStatement.setString(3, supplier.getPhoneNumber());
            preparedStatement.setString(4, supplier.getSupplierName());
            preparedStatement.setInt(5, supplier.getId());
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    String getTableName() {
        return "supplier";
    }

    @Override
    Supplier result2Model(ResultSet resultSet) {
        Supplier supplier = new Supplier();
        try {
            supplier.setId(resultSet.getInt("id"));
            supplier.setCreateTime(DateUtil.str2Date(resultSet.getString("createTime")));
            supplier.setUpdateTime(DateUtil.str2Date(resultSet.getString("updateTime")));

            supplier.setPhoneNumber(resultSet.getString("phoneNumber"));
            supplier.setSupplierName(resultSet.getString("supplierName"));
            supplier.setAddress(resultSet.getString("address"));

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return supplier;
    }
}
