package au.edu.unsw.business.infs2605.fxstarterkit.controller.order;

import au.edu.unsw.business.infs2605.fxstarterkit.controller.BaseTableController;
import au.edu.unsw.business.infs2605.fxstarterkit.dao.OrderDao;
import au.edu.unsw.business.infs2605.fxstarterkit.dao.ProductDao;
import au.edu.unsw.business.infs2605.fxstarterkit.dao.StoreDao;
import au.edu.unsw.business.infs2605.fxstarterkit.models.*;
import au.edu.unsw.business.infs2605.fxstarterkit.observers.Observable;
import au.edu.unsw.business.infs2605.fxstarterkit.observers.Observer;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.AppUtil;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.DateUtil;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.UIUtil;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

public class OrderListController extends BaseTableController<Order> {
    public TableColumn supplierNameCol;
    public TableColumn storeNameCol;
    public TableColumn statusCol;
    public TableColumn createUser;
    public TableColumn productsCol;
    public TableColumn createTimeCol;
    public TableColumn updateTimeCol;
    public TableColumn carriageTimeCol;
    public TableColumn cancelTimeCol;
    public TableColumn finishTimeCol;

    @Override
    protected TableView<Order> getTableView() {
        return this.tableView;
    }

    @Override
    protected TextField getTextFieldSearch() {
        return this.searchTextField;
    }



    public void initialize(URL location, ResourceBundle resources) {
        super.initialize(location, resources);
        this.supplierNameCol.setCellValueFactory(
                new PropertyValueFactory<Order, Supplier>("supplier"));
        supplierNameCol.setCellFactory(column -> {
            TableCell<Order, Supplier> cell = new TableCell<Order, Supplier>() {
                @Override
                protected void updateItem(Supplier item, boolean empty) {
                    super.updateItem(item, empty);
                    if(empty) {
                        setText(null);
                    }
                    else {
                        if(item != null)
                            this.setText(item.getSupplierName());
                    }
                }
            };
            return cell;
        });


        this.productsCol.setCellValueFactory(
                new PropertyValueFactory<Order, List<OrderProduct>>("products"));
        productsCol.setCellFactory(column -> {
            TableCell<Order, List<OrderProduct>> cell = new TableCell<Order, List<OrderProduct>>() {

                protected void updateItem(List<OrderProduct> item, boolean empty) {
                    super.updateItem(item, empty);
                    if(empty) {
                        setText(null);
                    }
                    else {
                        if(item != null)
//
                            this.setText(String.join("\n",
                                    item.stream()
                                            .map(op->op.toString()).collect(Collectors.toList())
                            ));
                    }
                }
            };
            return cell;
        });

        this.storeNameCol.setCellValueFactory(
                new PropertyValueFactory<Order, Store>("store"));
        storeNameCol.setCellFactory(column -> {
            TableCell<Order, Store> cell = new TableCell<Order, Store>() {
                @Override
                protected void updateItem(Store item, boolean empty) {
                    super.updateItem(item, empty);
                    if(empty) {
                        setText(null);
                    }
                    else {
                        if(item != null)
                            this.setText(item.getStoreName());
                    }
                }
            };
            return cell;
        });

        statusCol.setCellValueFactory(
                new PropertyValueFactory<Order, String>("status"));
        createUser.setCellValueFactory(
                new PropertyValueFactory<Product, User>("createUser"));

        createUser.setCellFactory(column -> {
            TableCell<Order, User> cell = new TableCell<Order, User>() {
                @Override
                protected void updateItem(User item, boolean empty) {
                    super.updateItem(item, empty);
                    if(empty) {
                        setText(null);
                    }
                    else {
                        if(item != null)
                            this.setText(item.getUserName());
                    }
                }
            };
            return cell;
        });

        createTimeCol.setCellValueFactory(
                new PropertyValueFactory<Product, Date>("createTime"));
        updateTimeCol.setCellValueFactory(
                new PropertyValueFactory<Product, Date>("updateTime"));

        cancelTimeCol.setCellValueFactory(
                new PropertyValueFactory<Product, Date>("cancelTime"));
        finishTimeCol.setCellValueFactory(
                new PropertyValueFactory<Product, Date>("finishTime"));
        carriageTimeCol.setCellValueFactory(
                new PropertyValueFactory<Product, Date>("carriageTime"));

        this.setColDateFormat(createTimeCol);
        this.setColDateFormat(updateTimeCol);
        this.setColDateFormat(cancelTimeCol);
        this.setColDateFormat(carriageTimeCol);
        this.setColDateFormat(finishTimeCol);
        this.initTableData();
        Observable.registerObserver(Observer.AddOrEditOrder, this);
        Observable.registerObserver(Observer.DeleteEvent, this);
    }

    @Override
    public void initTableData() {
        ;
        observableList = FXCollections.observableArrayList();
        if(AppUtil.loginUser.getUserType()==0){
            List<Order> orders = OrderDao.getOrderDao().listAll();

            observableList.addAll(orders);

        }else{
            observableList.addAll(AppUtil.loginUser.getOrders(true));
        }
        this.tableView.setItems(observableList);
    }



    @Override
    public void updateModel(Order order) {

    }

    @Override
    public void onAdded(Order order) {


        this.initTableData();


    }

    @Override
    public void onDeleted(Order order) {
            this.initTableData();
    }

    @Override
    public void onEdit(Order order) {

    }

    @Override
    public void onSelected(Order order) {

    }

    public void addOrder(ActionEvent actionEvent) {
        if(AppUtil.loginUser.getUserType()==2){
            UIUtil.alert("Unauthorized operation.");
            return ;
        }
        AppUtil.modelMap.remove("newOrEditOrder");
        UIUtil.showView("fxml/order/addOrEditOrder.fxml","add Order",false);
    }

    public void editOrder(ActionEvent actionEvent) {

        if (getSelectionItem() != null) {

            AppUtil.modelMap.put("newOrEditOrder", getSelectionItem());
            UIUtil.showView("fxml/order/addOrEditOrder.fxml","edit Order",false);
        }else{
            UIUtil.alert("Please select one.");
        }
    }

    public void deleteOrder(ActionEvent actionEvent) {
        if(AppUtil.loginUser.getUserType()==2){
            UIUtil.alert("Unauthorized operation.");
            return ;
        }
        if (getSelectionItem() != null) {
            if (UIUtil.showConfirmation()) {
                OrderDao.getOrderDao().delete(getSelectionItem());
//                this.initTableData();
                Observable.onDeleted(Observer.DeleteEvent,null);
            }
        }else{
            UIUtil.alert("Please select one.");
        }
    }
}
