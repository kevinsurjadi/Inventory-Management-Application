package au.edu.unsw.business.infs2605.fxstarterkit.utils;

public class SQL {

    public static final String CreateUserTableSQL = "create table user(\n" +
            "    id integer PRIMARY KEY autoincrement,\n" +
            "    createTime TIMESTAMP default (datetime('now', 'localtime')),\n" +
            "    updateTime TIMESTAMP default (datetime('now', 'localtime')),\n" +
            "    userName         varchar (50),\n" +
            "    password         varchar (50),\n" +
            "    fullName         varchar (50),\n" +
            "    userType         integer default 0,\n" +
            "    authorityId      integer default 0\n" +
            ");";
    public static final String CreateStoreTableSQL = "create table store(\n" +
            "    id integer PRIMARY KEY autoincrement,\n" +
            "    createTime TIMESTAMP default (datetime('now', 'localtime')),\n" +
            "    updateTime TIMESTAMP default (datetime('now', 'localtime')),\n" +
            "    address             varchar (200),\n" +
            "    phoneNumber         varchar (50),\n" +
            "    storeManger         varchar (50),\n" +
            "    storeName           varchar (50)\n" +
            ");";
    public static final String CreateSupplierTableSQL = "create table supplier(\n" +
            "    id integer PRIMARY KEY autoincrement,\n" +
            "    createTime TIMESTAMP default (datetime('now', 'localtime')),\n" +
            "    updateTime TIMESTAMP default (datetime('now', 'localtime')),\n" +
            "    address             varchar (200),\n" +
            "    phoneNumber         varchar (50),\n" +
            "    supplierName         varchar (50)\n" +
            ");";


    public static final String CreateProductTableSQL = "create table product(\n" +
            "    id integer PRIMARY KEY autoincrement,\n" +
            "    createTime TIMESTAMP default (datetime('now', 'localtime')),\n" +
            "    updateTime TIMESTAMP default (datetime('now', 'localtime')),\n" +
            "    productName             varchar (200),\n" +
            "    price        real,\n" +
            "    productType         varchar (50)\n" +
            ");";
    public static final String CreateOrderTableSQL = "create table `order`(\n" +
            "    id integer PRIMARY KEY autoincrement,\n" +
            "    createTime TIMESTAMP default (datetime('now', 'localtime')),\n" +
            "    updateTime TIMESTAMP default (datetime('now', 'localtime')),\n" +
            "    supplierId          integer default 0,\n" +
            "    storeId              integer default 0,\n" +
            "    userId              integer default 0,\n" +
            "    supplierName         varchar (50),\n" +
            "    status         varchar(50) default 'Order Placed',\n" +
            "    finishTime     TIMESTAMP default null,\n" +
            "    cancelTime     TIMESTAMP default null,\n" +
            "    carriageTime     TIMESTAMP default null\n" +
            ");";
    public static final String CreateOrderProductTableSQL = "create table orderProduct(\n" +
            "    id integer PRIMARY KEY autoincrement,\n" +
            "    createTime TIMESTAMP default (datetime('now', 'localtime')),\n" +
            "    updateTime TIMESTAMP default (datetime('now', 'localtime')),\n" +
            "    orderId          integer default 0,\n" +
            "    productId          integer default 0,\n" +
            "    productName         varchar (50),\n" +
            "    quantity         integer default 0\n" +
            ");";
/* user SQL start */
    public final static String FindByUserNameSQL="select * from user where userName=?";
    public final static String InsertUserSQL="insert into user(updateTime,userName,password,fullName,userType,authorityId) " +
            "values(?,?,?,?,?,?);";
    public final static String UpdateUserSQL="update user set updateTime=?,userName=?,password=?,fullName=?,userType=?,authorityId=? " +
            " where id=?;";
    public final static String ManagerStoreUserSQL="select * from user where userType=1 and authorityId=?;";
    public final static String SupplierStoreUserSQL="select * from user where userType=2 and authorityId=?;";
    /* user SQL end */

    /* store SQL start */
    public final static String InsertStoreSQL="insert into store(address,phoneNumber,storeManger,storeName) " +
            "values(?,?,?,?);";
    public final static String UpdateStoreSQL="update store set updateTime=?,address=?,phoneNumber=?,storeManger=?,storeName=?" +
            " where id=?;";
    /* store SQL end */

    /* supplier SQL start */



    public final static String InsertSupplierSQL="insert into supplier(address,phoneNumber,supplierName) " +
            "values(?,?,?);";
    public final static String UpdateSupplierSQL="update supplier set updateTime=?,address=?,phoneNumber=?,supplierName=? " +
            " where id=?;";
    /* supplier SQL end */


    /* product SQL start */
    public final static String InsertProductSQL="insert into product(productName,price,productType) " +
            "values(?,?,?);";
    public final static String UpdateProductSQL="update product set updateTime=?,productName=?,price=?,productType=? " +
            " where id=?;";
    /* product SQL end */

    /* order SQL start */


    public final static String InsertOrderSQL="insert into `order`(supplierId,storeId,userId,supplierName,status) " +
            "values(?,?,?,?,?);";
    public final static String UserOrderSQL="select * from `order` where userId=?;";
    public final static String StoreOrderSQL="select * from `order` where storeId=?;";
    public final static String SupplierOrderSQL="select * from `order` where supplierId=?;";
    public final static String StatusOrderSQL="select status,count(*) from `order` group by status";
    public final static String UpdateOrderSQL="update `order` set updateTime=?,supplierId=?,storeId=?,userId=?,supplierName=?,status=? " +
            ",finishTime=?,cancelTime=?,carriageTime=?" +
            " where id=?;";
    /* order SQL end */


    /* orderProduct SQL start */


    public final static String InsertOrderProductSQL="insert into orderProduct (orderId,productId,productName,quantity) " +
            "values(?,?,?,?);";
    public final static String UpdateOrderProductSQL="update  orderProduct  set updateTime=?,orderId=?,productId=?,productName=?,quantity=? " +
            " where id=?;";
    public final static String FindOrderProductByOrderIdSQL="select * from orderProduct where orderId=?;";
    /* order SQL end */

    public static String dropTableSQL(String tableName) {
        return String.format("drop table if exists %s ;", tableName);
    }
    public static final String[] TableNames=new String[]{"user","orderProduct","`order`","product","store","supplier"};
    public static String createTableSQL(String tableName) {
        if ("user".equalsIgnoreCase(tableName))
            return CreateUserTableSQL;
        if ("orderProduct".equalsIgnoreCase(tableName))
            return SQL.CreateOrderProductTableSQL;
        if ("`order`".equalsIgnoreCase(tableName))
            return SQL.CreateOrderTableSQL;
        if ("product".equalsIgnoreCase(tableName))
            return SQL.CreateProductTableSQL;
        if ("store".equalsIgnoreCase(tableName))
            return SQL.CreateStoreTableSQL;
        if ("supplier".equalsIgnoreCase(tableName))
            return SQL.CreateSupplierTableSQL;

        return String.format("drop table %s ;", tableName);
    }
    public static String selectSQL(String tableName){
        return String.format("select * from %s ",tableName);
    }
    public static String findByIdSQL(String tableName){
        return String.format("select * from %s where id=?",tableName);
    }
    public static String deleteByIdSQL(String tableName){
        return String.format("DELETE FROM  %s where id=? ;",tableName);
    }
}
