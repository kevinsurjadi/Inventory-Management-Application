package au.edu.unsw.business.infs2605.fxstarterkit.controller.supplier;

import au.edu.unsw.business.infs2605.fxstarterkit.controller.BaseTableController;
import au.edu.unsw.business.infs2605.fxstarterkit.dao.StoreDao;
import au.edu.unsw.business.infs2605.fxstarterkit.dao.SupplierDao;
import au.edu.unsw.business.infs2605.fxstarterkit.models.Store;
import au.edu.unsw.business.infs2605.fxstarterkit.models.Supplier;
import au.edu.unsw.business.infs2605.fxstarterkit.observers.Observable;
import au.edu.unsw.business.infs2605.fxstarterkit.observers.Observer;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.AppUtil;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.UIUtil;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

public class SupplierListController extends BaseTableController<Supplier> {
    public TableColumn supplierNameCol;
    public TableColumn phoneNumberCol;
    public TableColumn addressCol;
    public TableColumn createTimeCol;
    private List<Supplier> suppliers;




    public void addSupplier(ActionEvent actionEvent) {
        if(AppUtil.loginUser.getUserType()>0){
            UIUtil.alert("Unauthorized operation.");
            return ;
        }
        AppUtil.modelMap.remove("newOrEditSupplier");
        UIUtil.showView("fxml/supplier/addOrEditSupplier.fxml","add Supplier",false);
    }

    public void editSupplier(ActionEvent actionEvent) {
        if(AppUtil.loginUser.getUserType()>0){
            UIUtil.alert("Unauthorized operation.");
            return ;
        }
        if (getSelectionItem() != null) {
            AppUtil.modelMap.put("newOrEditSupplier", getSelectionItem());
            UIUtil.showView("fxml/supplier/addOrEditSupplier.fxml","add Supplier",false);
        }else{
            UIUtil.alert("Please select one.");
        }
    }

    public void deleteSupplier(ActionEvent actionEvent) {
        if(AppUtil.loginUser.getUserType()>0){
            UIUtil.alert("Unauthorized operation.");
            return ;
        }
        if (getSelectionItem() != null) {
            if (UIUtil.showConfirmation()) {
                SupplierDao.getSupplierDao().delete(getSelectionItem());
//                this.initTableData();
                Observable.onDeleted(Observer.DeleteEvent,null);
            }
        }else{
            UIUtil.alert("Please select one.");
        }
    }

    @Override
    public void initTableData() {
        suppliers= SupplierDao.getSupplierDao().listAll();
        observableList = FXCollections.observableArrayList();
        observableList.addAll(suppliers);
        this.tableView.setItems(observableList);
    }
    public void initialize(URL location, ResourceBundle resources) {
       super.initialize(location,resources);
        this.supplierNameCol.setCellValueFactory(
                new PropertyValueFactory<Supplier,String>("supplierName"));
        phoneNumberCol.setCellValueFactory(
                new PropertyValueFactory<Supplier,String>("phoneNumber"));
        addressCol.setCellValueFactory(
                new PropertyValueFactory<Supplier,String>("address"));
        createTimeCol.setCellValueFactory(
                new PropertyValueFactory<Supplier, Date>("createTime"));
        this.initTableData();
        Observable.registerObserver(Observer.AddOrEditSupplier,this);
        Observable.registerObserver(Observer.DeleteEvent,this);
    }

    @Override
    protected TableView<Supplier> getTableView() {
        return this.tableView;
    }

    @Override
    protected TextField getTextFieldSearch() {
        return this.searchTextField;
    }


    @Override
    public void updateModel(Supplier supplier) {

    }

    @Override
    public void onAdded(Supplier supplier) {
        this.initTableData();
    }

    @Override
    public void onDeleted(Supplier supplier) {
        this.initTableData();
    }

    @Override
    public void onEdit(Supplier supplier) {

    }

    @Override
    public void onSelected(Supplier supplier) {

    }
}
