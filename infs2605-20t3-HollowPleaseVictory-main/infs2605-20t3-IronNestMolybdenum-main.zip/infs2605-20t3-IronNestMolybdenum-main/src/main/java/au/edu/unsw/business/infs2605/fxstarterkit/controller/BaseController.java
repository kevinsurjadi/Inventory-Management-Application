package au.edu.unsw.business.infs2605.fxstarterkit.controller;

import au.edu.unsw.business.infs2605.fxstarterkit.models.BaseModel;
import au.edu.unsw.business.infs2605.fxstarterkit.observers.Observer;
import javafx.beans.Observable;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public abstract class BaseController<T extends BaseModel> implements Initializable, Observer<T> {
    public T model;
    @FXML
    private AnchorPane topPane;

    public void setModel(T t) {
        this.model = t;
        this.updateModel(t);
    }

    public abstract void updateModel(T t);

    public Stage getStage() {
        if (this.topPane == null) return null;
        return ((Stage) topPane.getScene().getWindow());
    }

    public void closeWindow() {
        if (this.topPane != null)
            this.getStage().close();
    }


}
