package au.edu.unsw.business.infs2605.fxstarterkit.dao;

import au.edu.unsw.business.infs2605.fxstarterkit.models.Product;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.DBUtil;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.DateUtil;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.SQL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ProductDao extends BaseDao<Product> {

    private static ProductDao productDao=new ProductDao();

    private ProductDao(){}

    public static ProductDao getProductDao(){
        return productDao;
    }

    @Override
    public void save(Product product) {
        if (product.getId() > 0)
            this.update(product);
        else {
            try (Connection connection = DBUtil.createConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement(SQL.InsertProductSQL)) {

                preparedStatement.setString(1, product.getProductName());
                preparedStatement.setDouble(2, product.getPrice());
                preparedStatement.setString(3, product.getProductType());

                preparedStatement.executeUpdate();

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void update(Product product) {
        try (Connection connection = DBUtil.createConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SQL.UpdateProductSQL)) {
            preparedStatement.setString(1, DateUtil.date2Str(new java.util.Date()));
            preparedStatement.setString(2, product.getProductName());
            preparedStatement.setDouble(3, product.getPrice());
            preparedStatement.setString(4, product.getProductType());
            preparedStatement.setInt(5, product.getId());
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    String getTableName() {
        return "product";
    }

    @Override
    Product result2Model(ResultSet resultSet) {
        Product product = new Product();
        try {
            product.setId(resultSet.getInt("id"));
            product.setCreateTime(DateUtil.str2Date(resultSet.getString("createTime")));
            product.setUpdateTime(DateUtil.str2Date(resultSet.getString("updateTime")));

            product.setProductName(resultSet.getString("productName"));
            product.setPrice(resultSet.getDouble("price"));
            product.setProductType(resultSet.getString("productType"));

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return product;

    }
}
