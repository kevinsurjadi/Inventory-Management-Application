package au.edu.unsw.business.infs2605.fxstarterkit.models;

import au.edu.unsw.business.infs2605.fxstarterkit.dao.UserDao;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.DateUtil;

import java.util.ArrayList;
import java.util.List;

public class Store  extends BaseModel {
    private String address;
    private String phoneNumber;
    private String storeManger;

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    private String storeName;

    private List<Order> orders;

    private User mangerUser;
    public Store(){}

    public List<User> getStoreUsers(){
        if(getId()>0){
           return  UserDao.getUserDao().getManagerUsers(getId());
        }
        return new ArrayList<>();
    }
    public User getMangerUser() {
       return this.getMangerUser(false);
    }
    public User getMangerUser(boolean lazy) {

        return mangerUser;
    }
    public void setMangerUser(User mangerUser) {
        this.mangerUser = mangerUser;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getStoreManger() {
        return storeManger;
    }

    public void setStoreManger(String storeManger) {
        this.storeManger = storeManger;
    }

    @Override
    public String getTableName() {
        return "store";
    }

    @Override
    public String toStringForSearch() {
        return String.join(" ",this.storeManger,this.phoneNumber,this.address, DateUtil.date2Str(this.getCreateTime()));
    }
}
