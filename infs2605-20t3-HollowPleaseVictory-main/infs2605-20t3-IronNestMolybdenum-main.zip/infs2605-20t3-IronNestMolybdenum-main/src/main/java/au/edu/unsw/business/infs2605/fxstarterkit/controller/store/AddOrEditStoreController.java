package au.edu.unsw.business.infs2605.fxstarterkit.controller.store;

import au.edu.unsw.business.infs2605.fxstarterkit.controller.BaseController;
import au.edu.unsw.business.infs2605.fxstarterkit.dao.StoreDao;
import au.edu.unsw.business.infs2605.fxstarterkit.models.Store;
import au.edu.unsw.business.infs2605.fxstarterkit.observers.Observable;
import au.edu.unsw.business.infs2605.fxstarterkit.observers.Observer;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.AppUtil;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.UIUtil;
import javafx.event.ActionEvent;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ResourceBundle;

public class AddOrEditStoreController extends BaseController<Store> {
    public TextField phoneNumberTxt;
    public TextArea addressTxt;
    public TextField storeMangerTxt;
    public TextField storeNameTxt;

    @Override
    public void updateModel(Store store) {

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        this.model = (Store) AppUtil.modelMap.getOrDefault("newOrEditStore", new Store());
        this.phoneNumberTxt.setText(model.getPhoneNumber());
        this.addressTxt.setText(model.getAddress());
        this.storeMangerTxt.setText(model.getStoreManger());
        this.storeNameTxt.setText(model.getStoreName());

    }

    public void doSaveOrUpdate(ActionEvent actionEvent) {
        if (this.phoneNumberTxt.getText().isEmpty()) {
            UIUtil.alert("Please input phoneNumber.");
            return;
        }
        if (this.addressTxt.getText().isEmpty()) {
            UIUtil.alert("Please input address.");
            return;
        }
        if (this.storeMangerTxt.getText().isEmpty()) {
            UIUtil.alert("Please input store manger.");
            return;
        }
        this.model.setAddress(this.addressTxt.getText());
        this.model.setPhoneNumber(this.phoneNumberTxt.getText());
        this.model.setStoreManger(this.storeMangerTxt.getText());
        this.model.setStoreName(this.storeNameTxt.getText());
        StoreDao.getStoreDao().save(this.model);
        UIUtil.alert("SUCCESS.");
        this.closeWindow();
        Observable.onAdded(Observer.AddStore,this.model);

    }

    public void doCancel(ActionEvent actionEvent) {
        this.closeWindow();
    }

    public void selectUser(ActionEvent actionEvent) {

    }

    @Override
    public void onAdded(Store store) {

    }

    @Override
    public void onDeleted(Store store) {

    }

    @Override
    public void onEdit(Store store) {

    }

    @Override
    public void onSelected(Store store) {

    }
}
