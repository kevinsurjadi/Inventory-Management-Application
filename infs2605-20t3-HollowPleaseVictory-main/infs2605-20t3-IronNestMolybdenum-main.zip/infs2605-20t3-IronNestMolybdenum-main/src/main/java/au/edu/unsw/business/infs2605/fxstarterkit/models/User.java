package au.edu.unsw.business.infs2605.fxstarterkit.models;

import au.edu.unsw.business.infs2605.fxstarterkit.dao.OrderDao;
import au.edu.unsw.business.infs2605.fxstarterkit.dao.StoreDao;
import au.edu.unsw.business.infs2605.fxstarterkit.dao.SupplierDao;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.DateUtil;

import java.util.Arrays;
import java.util.List;

public class User extends BaseModel {

    public final static String[] USER_TYPES =new String[]{"Admin","Store Manager","Supplier staff"};
    public final static List<String> USER_TYPES_LIST = Arrays.asList("Admin","Store Manager","Supplier staff");

    private String userName;
    private String password;
    private String fullName;
    private int userType;
    private int authorityId;
    private String ssName;
    private String userTypeName;

    private List<Order> orders;
    private Store store;




    public Store getStore(boolean lazy) {
        if((lazy ||store==null) && userType==1){
            store= StoreDao.getStoreDao().findById(authorityId);
        }
        return store;
    }

    public void setStore(Store store) {
        this.store = store;
    }

    public Supplier getSupplier(boolean lazy) {
        if((lazy ||supplier==null) && userType==2){
            supplier= SupplierDao.getSupplierDao().findById(authorityId);
        }
        return supplier;
    }

    public void setSupplier(Supplier supplier) {
        this.supplier = supplier;
    }

    private Supplier supplier;

    public User(){

    }

    public User(String userName, String password, String fullName, int userType, int authorityId) {
        this.userName = userName;
        this.password = password;
        this.fullName = fullName;
        this.userType = userType;
        this.authorityId = authorityId;
    }

    public String getSsName() {
        if(userType==1){
            Store v = this.getStore(false);
            if(v!=null) return v.getStoreName();
        }else if(userType==2){
            Supplier v = this.getSupplier(false);
            if(v!=null) return v.getSupplierName();
        }
        return ssName;
    }

    public void setSsName(String ssName) {
        this.ssName = ssName;
    }

    public String getUserTypeName() {
        if(this.userType<=2) return USER_TYPES[userType];
        return userTypeName;
    }

    public void setUserTypeName(String userTypeName) {
        this.userTypeName = userTypeName;
    }

    public int getAuthorityId() {
        return authorityId;
    }

    public void setAuthorityId(int authorityId) {
        this.authorityId = authorityId;
    }



    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public int getUserType() {
        return userType;
    }

    public void setUserType(int userType) {
        this.userType = userType;
    }

    @Override
    public String getTableName() {
        return "user";
    }

    @Override
    public String toStringForSearch() {
        return String.join(" ",this.userName,this.fullName,this.getUserTypeName(),this.getSsName(), DateUtil.date2Str(this.getCreateTime()));
    }

    public List<Order> getOrders(boolean refresh) {
        if((orders==null || refresh) && getId()>0){
            orders=OrderDao.getOrderDao().findUserOrder(getId());
        }
        return orders;
    }

    public void setOrders(List<Order> orders) {
        this.orders = orders;
    }
}
