package au.edu.unsw.business.infs2605.fxstarterkit.dao;

import au.edu.unsw.business.infs2605.fxstarterkit.models.BaseModel;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.DBUtil;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.SQL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public abstract class BaseDao<T extends BaseModel> {

   public T findById(int id) {
        try (Connection connection = DBUtil.createConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SQL.findByIdSQL(getTableName()))) {
            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                return this.result2Model(resultSet);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public abstract void save(T t);

    public abstract void update(T t);

    public void deleteById(int id) {
        try (Connection connection = DBUtil.createConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SQL.deleteByIdSQL(this.getTableName()))) {
            connection.setAutoCommit(false);
            preparedStatement.setInt(1, id);
            preparedStatement.execute();
            connection.commit();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public void delete(T t) {
        this.deleteById(((BaseModel) t).getId());
    }

    public List<T> listAll() {
        List<T> data = new ArrayList<>();
        System.out.println(SQL.selectSQL(getTableName()));
        try (Connection connection = DBUtil.createConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SQL.selectSQL(getTableName()))) {
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                data.add(this.result2Model(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return data;
    }

    abstract String getTableName();

    abstract T result2Model(ResultSet resultSet);


}
