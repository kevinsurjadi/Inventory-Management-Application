package au.edu.unsw.business.infs2605.fxstarterkit.controller.supplier;

import au.edu.unsw.business.infs2605.fxstarterkit.controller.BaseTableController;
import au.edu.unsw.business.infs2605.fxstarterkit.dao.SupplierDao;
import au.edu.unsw.business.infs2605.fxstarterkit.models.Supplier;
import au.edu.unsw.business.infs2605.fxstarterkit.observers.Observable;
import au.edu.unsw.business.infs2605.fxstarterkit.observers.Observer;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.AppUtil;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.UIUtil;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

public class SelectSupplierController extends BaseTableController<Supplier> {
    public TableColumn supplierNameCol;
    public TableColumn phoneNumberCol;
    public TableColumn addressCol;
    public TableColumn createTimeCol;

    @Override
    protected TableView<Supplier> getTableView() {
        return this.tableView;
    }

    @Override
    protected TextField getTextFieldSearch() {
        return null;
    }

    @Override
    public void initTableData() {
        List<Supplier> suppliers = SupplierDao.getSupplierDao().listAll();
        observableList = FXCollections.observableArrayList();
        observableList.addAll(suppliers);
        this.tableView.setItems(observableList);
    }

    public void initialize(URL location, ResourceBundle resources) {
        super.initialize(location,resources);
        this.supplierNameCol.setCellValueFactory(
                new PropertyValueFactory<Supplier,String>("supplierName"));
        phoneNumberCol.setCellValueFactory(
                new PropertyValueFactory<Supplier,String>("phoneNumber"));
        addressCol.setCellValueFactory(
                new PropertyValueFactory<Supplier,String>("address"));
        createTimeCol.setCellValueFactory(
                new PropertyValueFactory<Supplier, Date>("createTime"));
        this.setColDateFormat(this.createTimeCol);
        this.initTableData();

    }


    @Override
    public void updateModel(Supplier supplier) {

    }

    @Override
    public void onAdded(Supplier supplier) {

    }

    @Override
    public void onDeleted(Supplier supplier) {

    }

    @Override
    public void onEdit(Supplier supplier) {

    }

    @Override
    public void onSelected(Supplier supplier) {

    }

    public void doSelect(ActionEvent actionEvent) {
        if (getSelectionItem() != null) {
            AppUtil.modelMap.put("SelectSupplier", getSelectionItem());
            Observable.onSelected(Observer.SelectSupplier,null);
            this.closeWindow();
        }else{
            UIUtil.alert("Please select one.");
        }
    }

    public void doCancel(ActionEvent actionEvent) {
        this.closeWindow();
    }
}
