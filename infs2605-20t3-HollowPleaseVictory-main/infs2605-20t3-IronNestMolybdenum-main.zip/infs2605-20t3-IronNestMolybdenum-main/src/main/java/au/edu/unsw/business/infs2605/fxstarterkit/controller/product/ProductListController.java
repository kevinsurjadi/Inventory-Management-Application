package au.edu.unsw.business.infs2605.fxstarterkit.controller.product;

import au.edu.unsw.business.infs2605.fxstarterkit.controller.BaseTableController;
import au.edu.unsw.business.infs2605.fxstarterkit.dao.ProductDao;
import au.edu.unsw.business.infs2605.fxstarterkit.models.Product;
import au.edu.unsw.business.infs2605.fxstarterkit.observers.Observable;
import au.edu.unsw.business.infs2605.fxstarterkit.observers.Observer;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.AppUtil;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.UIUtil;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

public class ProductListController extends BaseTableController<Product> {
    public TableColumn productNameCol;
    public TableColumn productTypeCol;
    public TableColumn priceCol;
    public TableColumn createTimeCol;
    public TableColumn updateTimeCol;
    private List<Product> products;

    @Override
    protected TableView<Product> getTableView() {
        return this.tableView;
    }


    public void initialize(URL location, ResourceBundle resources) {
        super.initialize(location, resources);
        this.productNameCol.setCellValueFactory(
                new PropertyValueFactory<Product, String>("productName"));
        priceCol.setCellValueFactory(
                new PropertyValueFactory<Product, String>("price"));
        productTypeCol.setCellValueFactory(
                new PropertyValueFactory<Product, String>("productType"));
        createTimeCol.setCellValueFactory(
                new PropertyValueFactory<Product, Date>("createTime"));
        updateTimeCol.setCellValueFactory(
                new PropertyValueFactory<Product, Date>("updateTime"));
        this.setColDateFormat(createTimeCol);
        this.setColDateFormat(updateTimeCol);
        this.initTableData();
        Observable.registerObserver(Observer.AddOrEditProduct, this);
    }


    @Override
    protected TextField getTextFieldSearch() {
        return this.searchTextField;
    }

    @Override
    public void initTableData() {
        products = ProductDao.getProductDao().listAll();
        observableList = FXCollections.observableArrayList();
        observableList.addAll(products);
        this.tableView.setItems(observableList);
    }


    @Override
    public void updateModel(Product product) {

    }

    @Override
    public void onAdded(Product product) {
        this.initTableData();
    }

    @Override
    public void onDeleted(Product product) {

    }

    @Override
    public void onEdit(Product product) {

    }

    @Override
    public void onSelected(Product product) {

    }

    public void addProduct(ActionEvent actionEvent) {
        if(AppUtil.loginUser.getUserType()>0){
            UIUtil.alert("Unauthorized operation.");
            return ;
        }
        AppUtil.modelMap.remove("newOrEditProduct");
        UIUtil.showView("fxml/product/addOrEditProduct.fxml", "add Product", false);
    }

    public void editProduct(ActionEvent actionEvent) {
        if(AppUtil.loginUser.getUserType()>0){
            UIUtil.alert("Unauthorized operation.");
            return ;
        }
        if (getSelectionItem() != null) {
            AppUtil.modelMap.put("newOrEditProduct", getSelectionItem());
            UIUtil.showView("fxml/product/addOrEditProduct.fxml", "Edit Product", false);
        } else {
            UIUtil.alert("Please select one.");
        }
    }

    public void deleteProduct(ActionEvent actionEvent) {
        if(AppUtil.loginUser.getUserType()>0){
            UIUtil.alert("Unauthorized operation.");
            return ;
        }
        if (getSelectionItem() != null) {
            if (UIUtil.showConfirmation()) {
                ProductDao.getProductDao().delete(getSelectionItem());
                this.initTableData();
            }
        } else {
            UIUtil.alert("Please select one.");
        }
    }
}
