package au.edu.unsw.business.infs2605.fxstarterkit.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {

    public static Date str2Date(String dateStr, String dateFormat){
        SimpleDateFormat sdf=new SimpleDateFormat(dateFormat);
        try {
            return sdf.parse(dateStr);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }
    public static Date str2Date(String dateStr){
       return  str2Date(dateStr,"yyyy-MM-dd HH:mm:ss");
    }

    public static String date2Str(Date date,String dateFormat){
        SimpleDateFormat sdf=new SimpleDateFormat(dateFormat);
        return sdf.format(date);
    }

    public static String date2Str(Date date){
        return date2Str(date,"yyyy-MM-dd HH:mm:ss");
    }
}
