package au.edu.unsw.business.infs2605.fxstarterkit.controller.product;

import au.edu.unsw.business.infs2605.fxstarterkit.controller.BaseController;
import au.edu.unsw.business.infs2605.fxstarterkit.dao.ProductDao;
import au.edu.unsw.business.infs2605.fxstarterkit.models.Product;
import au.edu.unsw.business.infs2605.fxstarterkit.observers.Observable;
import au.edu.unsw.business.infs2605.fxstarterkit.observers.Observer;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.AppUtil;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.UIUtil;
import javafx.event.ActionEvent;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ResourceBundle;

public class AddOrEditProductController extends BaseController<Product> {

    public TextField productNameTxt;
    public TextField priceTxt;
    public TextField productTypeTxt;

    @Override
    public void updateModel(Product product) {

    }

    @Override
    public void onAdded(Product product) {

    }

    @Override
    public void onDeleted(Product product) {

    }

    @Override
    public void onEdit(Product product) {

    }

    @Override
    public void onSelected(Product product) {

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        this.model = (Product) AppUtil.modelMap.getOrDefault("newOrEditProduct", new Product());
        this.productNameTxt.setText(model.getProductName());
        this.productTypeTxt.setText(model.getProductType());
        this.priceTxt.setText(String.valueOf(model.getPrice()));
    }

    public void doSaveOrUpdate(ActionEvent actionEvent) {
        if (this.productNameTxt.getText().isEmpty()) {
            UIUtil.alert("Please input productName.");
            return;
        }
        if (this.productNameTxt.getText().isEmpty()) {
            UIUtil.alert("Please input product.");
            return;
        }
        if (this.priceTxt.getText().isEmpty()) {
            UIUtil.alert("Please input store manger.");
            return;
        }
        if (!isNumber(this.priceTxt.getText())) {
            UIUtil.alert("Price must a number.");
            return;
        }
        this.model.setProductName(this.productNameTxt.getText());
        this.model.setProductType(this.productTypeTxt.getText());
        this.model.setPrice(Double.parseDouble(this.priceTxt.getText()));
        ProductDao.getProductDao().save(this.model);
        UIUtil.alert("SUCCESS.");
        this.closeWindow();
        Observable.onAdded(Observer.AddOrEditProduct,this.model);
    }


    private boolean isNumber(String num){
        try{
            Double.parseDouble(num);
            return true;
        }catch (Exception e){

        }
        return false;
    }

    public void doCancel(ActionEvent actionEvent) {
        this.closeWindow();
    }
}
