package au.edu.unsw.business.infs2605.fxstarterkit.controller.supplier;

import au.edu.unsw.business.infs2605.fxstarterkit.controller.BaseController;
import au.edu.unsw.business.infs2605.fxstarterkit.dao.SupplierDao;
import au.edu.unsw.business.infs2605.fxstarterkit.models.Supplier;
import au.edu.unsw.business.infs2605.fxstarterkit.observers.Observable;
import au.edu.unsw.business.infs2605.fxstarterkit.observers.Observer;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.AppUtil;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.UIUtil;
import javafx.event.ActionEvent;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ResourceBundle;

public class AddOrEditSupplierController extends BaseController<Supplier> {
    public TextField supplierNameTxt;
    public TextArea addressTxt;
    public TextField phoneNumberTxt;

    @Override
    public void updateModel(Supplier supplier) {

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        this.model = (Supplier) AppUtil.modelMap.getOrDefault("newOrEditSupplier", new Supplier());
        this.phoneNumberTxt.setText(model.getPhoneNumber());
        this.addressTxt.setText(model.getAddress());
        this.supplierNameTxt.setText(model.getSupplierName());
    }

    @Override
    public void onAdded(Supplier supplier) {

    }

    @Override
    public void onDeleted(Supplier supplier) {

    }

    @Override
    public void onEdit(Supplier supplier) {

    }

    @Override
    public void onSelected(Supplier supplier) {

    }

    public void doSaveOrUpdate(ActionEvent actionEvent) {
        if (this.phoneNumberTxt.getText().isEmpty()) {
            UIUtil.alert("Please input phoneNumber.");
            return;
        }
        if (this.addressTxt.getText().isEmpty()) {
            UIUtil.alert("Please input address.");
            return;
        }
        if (this.supplierNameTxt.getText().isEmpty()) {
            UIUtil.alert("Please input supplierName.");
            return;
        }
        this.model.setAddress(this.addressTxt.getText());
        this.model.setPhoneNumber(this.phoneNumberTxt.getText());
        this.model.setSupplierName(this.supplierNameTxt.getText());
        SupplierDao.getSupplierDao().save(this.model);
        UIUtil.alert("SUCCESS.");
        this.closeWindow();
        Observable.onAdded(Observer.AddOrEditSupplier,this.model);
    }

    public void doCancel(ActionEvent actionEvent) {
    }
}
