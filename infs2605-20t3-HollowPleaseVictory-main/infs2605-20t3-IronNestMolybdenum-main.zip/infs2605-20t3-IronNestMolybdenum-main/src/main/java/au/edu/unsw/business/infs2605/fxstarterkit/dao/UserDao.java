package au.edu.unsw.business.infs2605.fxstarterkit.dao;

import au.edu.unsw.business.infs2605.fxstarterkit.models.Order;
import au.edu.unsw.business.infs2605.fxstarterkit.models.User;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.DBUtil;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.DateUtil;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.SQL;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDao extends BaseDao<User> {

    private static UserDao userDao = new UserDao();


    private UserDao() {
    }

    @Override
    public void deleteById(int id) {
      this.delete(findById(id));
    }

    @Override
    public void delete(User user) {
        List<Order> orders = user.getOrders(true);
       for(Order o:orders){
           OrderDao.getOrderDao().delete(o);
       }
       super.deleteById(user.getId());
    }

    public List<User> getSupplierUsers(int supplierId){
        List<User> data = new ArrayList<>();
        System.out.println(SQL.selectSQL(getTableName()));
        try (Connection connection = DBUtil.createConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SQL.SupplierStoreUserSQL)) {
            preparedStatement.setInt(1, supplierId);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                data.add(this.result2Model(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return data;
    }
    public List<User> getManagerUsers(int storeId){
        List<User> data = new ArrayList<>();
        System.out.println(SQL.selectSQL(getTableName()));
        try (Connection connection = DBUtil.createConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SQL.ManagerStoreUserSQL)) {
            preparedStatement.setInt(1, storeId);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                data.add(this.result2Model(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return data;
    }


    public User findByUserName(String userName) {

        try (Connection connection = DBUtil.createConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SQL.FindByUserNameSQL)) {
            preparedStatement.setString(1, userName);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                return this.result2Model(resultSet);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static UserDao getUserDao() {
        return userDao;
    }





    @Override
    public void save(User user) {
        if(user.getId()>0)
            this.update(user);
        else{
            try (Connection connection = DBUtil.createConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement(SQL.InsertUserSQL)) {

                preparedStatement.setString(1,DateUtil.date2Str(new java.util.Date()));
                preparedStatement.setString(2,user.getUserName());
                preparedStatement.setString(3,user.getPassword());
                preparedStatement.setString(4,user.getFullName());
                preparedStatement.setInt(5, user.getUserType());
                preparedStatement.setInt(6, user.getAuthorityId());

                preparedStatement.executeUpdate();

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void update(User user) {
        try (Connection connection = DBUtil.createConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SQL.UpdateUserSQL)) {
            preparedStatement.setString(1,DateUtil.date2Str(new java.util.Date()));
            preparedStatement.setString(2,user.getUserName());
            preparedStatement.setString(3,user.getPassword());
            preparedStatement.setString(4,user.getFullName());
            preparedStatement.setInt(5, user.getUserType());
            preparedStatement.setInt(6, user.getAuthorityId());
            preparedStatement.setInt(7, user.getId());


            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    String getTableName() {
        return "user";
    }

    @Override
    User result2Model(ResultSet resultSet) {
        User user = new User();
        try {
            user.setId(resultSet.getInt("id"));
            user.setCreateTime(DateUtil.str2Date(resultSet.getString("createTime")));
            user.setUpdateTime(DateUtil.str2Date(resultSet.getString("updateTime")));

            user.setUserName(resultSet.getString("userName"));
            user.setPassword(resultSet.getString("password"));
            user.setFullName(resultSet.getString("fullName"));

            user.setAuthorityId(resultSet.getInt("authorityId"));
            user.setUserType(resultSet.getInt("userType"));

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return user;
    }
}
