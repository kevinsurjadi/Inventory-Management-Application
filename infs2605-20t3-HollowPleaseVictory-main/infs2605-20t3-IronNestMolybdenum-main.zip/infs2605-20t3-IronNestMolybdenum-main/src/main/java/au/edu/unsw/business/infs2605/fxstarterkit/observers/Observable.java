package au.edu.unsw.business.infs2605.fxstarterkit.observers;

import au.edu.unsw.business.infs2605.fxstarterkit.models.BaseModel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Observable {
//    private static List<Observer> observers = new ArrayList<>();
    private static Map<String,List<Observer>> observers = new HashMap<>();


    public static void registerObserver(String event,Observer observer) {
//        observers.add(observer);
        removeObserver(null);
        if(!observers.keySet().contains(event)){
            observers.put(event,new ArrayList<Observer>());
        }
        observers.get(event).add(observer);
    }


    public static void removeEventObserver(String event){
        if(observers.keySet().contains(event)){
            observers.get(event).clear();
        }
    }

    public static void removeObserver(Observer observer) {
        for(String event:observers.keySet()){
            observers.get(event).remove(observer);
        }
    }

    public static void onAdded(String event,BaseModel t) {
        if(!observers.keySet().contains(event)){
            return;
        }
        for (Observer obs : observers.get(event)) {
            obs.onAdded(t);
        }
    }

    public static void onDeleted(String event,BaseModel t) {
        for (Observer obs : observers.get(event)) {
            obs.onDeleted(t);
        }
    }

    public static void onEdit(String event,BaseModel t) {
        for (Observer obs : observers.get(event)) {
            obs.onEdit(t);
        }
    }

    public static void onSelected(String event,BaseModel t) {
        for (Observer obs : observers.get(event)) {
            obs.onSelected(t);
        }
    }
}
