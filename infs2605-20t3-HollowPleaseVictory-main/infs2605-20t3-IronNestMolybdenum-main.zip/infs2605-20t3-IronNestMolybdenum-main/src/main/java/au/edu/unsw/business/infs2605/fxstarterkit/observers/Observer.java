package au.edu.unsw.business.infs2605.fxstarterkit.observers;

import au.edu.unsw.business.infs2605.fxstarterkit.models.BaseModel;

public interface Observer<T extends BaseModel> {

    public final static String DeleteEvent="DeleteEvent";


    public final static String StoreSelectUser="StoreSelectUser";
    public final static String AddStore="AddStore";
    public final static String EditStore="EditStore";


    public final static String AddOrEditUser="AddOrEditUser";

    public final static String AddOrEditSupplier="AddOrEditSupplier";
    public final static String SelectSupplier="SelectSupplier";
    public final static String SelectStore="SelectStore";
    public final static String SelectProduct="SelectProduct";

    public final static String AddOrEditProduct ="AddOrEditProduct";
    public final static String AddOrEditOrder="AddOrEditOrder";

    void onAdded(T t);
    void onDeleted(T t);
    void onEdit(T t);
    void onSelected(T t);
}
