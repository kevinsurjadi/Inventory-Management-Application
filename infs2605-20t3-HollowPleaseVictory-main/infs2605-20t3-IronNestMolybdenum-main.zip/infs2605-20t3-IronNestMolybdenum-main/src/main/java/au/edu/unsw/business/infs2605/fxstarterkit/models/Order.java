package au.edu.unsw.business.infs2605.fxstarterkit.models;

import au.edu.unsw.business.infs2605.fxstarterkit.dao.OrderProductDao;
import au.edu.unsw.business.infs2605.fxstarterkit.dao.StoreDao;
import au.edu.unsw.business.infs2605.fxstarterkit.dao.SupplierDao;
import au.edu.unsw.business.infs2605.fxstarterkit.dao.UserDao;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

public class Order extends BaseModel {


    public final static String[] STATUS=new String[]{"Order Placed","In Transit","Order Cancel","Order Finish"};


    private int supplierId;
    private int storeId;



    private int userId;
    private String supplierName;
    private String status="Order Placed";

    private Date finishTime;
    private Date cancelTime;
    private Date carriageTime;

    private double totalPrice;


    private List<OrderProduct> products;
    private User createUser;
    private Supplier supplier;
    private Store store;



    public List<OrderProduct> getProducts(){
        return this.getProducts(false);
    }
    public List<OrderProduct> getProducts(boolean refresh) {
        if(getId()>0 && (products==null ||  refresh)){
            products=OrderProductDao.getOrderProductDao().findByOrderId(getId());
        }
        return products;
    }

    public void setProducts(List<OrderProduct> products) {
        this.products = products;
    }
    public User getCreateUser(){
        return getCreateUser(false);
    }
    public User getCreateUser(boolean refresh) {
        if(getId()>0 && (createUser==null ||  refresh)){
            createUser= UserDao.getUserDao().findById(this.getUserId());
        }
        return createUser;
    }

    public void setCreateUser(User createUser) {
        this.createUser = createUser;
    }
    public Supplier getSupplier(){
        return this.getSupplier(false);
    }
    public Supplier getSupplier(boolean refresh) {
        if(getId()>0 && (supplier==null ||  refresh)){
            supplier= SupplierDao.getSupplierDao().findById(this.getSupplierId());
        }
        return supplier;
    }

    public void setSupplier(Supplier supplier) {
        this.supplier = supplier;
    }
    public Store getStore() {
      return this.getStore(false);
    }
    public Store getStore(boolean refresh) {
        if(getId()>0 && (store==null ||  refresh)){
            store= StoreDao.getStoreDao().findById(this.getStoreId());
        }
        return store;
    }

    public void setStore(Store store) {
        this.store = store;
    }

    public int getStoreId() {
        return storeId;
    }

    public void setStoreId(int storeId) {
        this.storeId = storeId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }
    public String getSupplierName() {
        return supplierName;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public Date getFinishTime() {
        return finishTime;
    }

    public void setFinishTime(Date finishTime) {
        this.finishTime = finishTime;
    }

    public Date getCancelTime() {
        return cancelTime;
    }

    public void setCancelTime(Date cancelTime) {
        this.cancelTime = cancelTime;
    }

    public Date getCarriageTime() {
        return carriageTime;
    }

    public void setCarriageTime(Date carriageTime) {
        this.carriageTime = carriageTime;
    }


    public int getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(int supplierId) {
        this.supplierId = supplierId;
    }

    @Override
    public String getTableName() {
        return "`order`";
    }

    @Override
    public String toStringForSearch() {

       return  String.join(" ",this.getStore().getStoreName()
        ,this.getSupplier().getSupplierName(),String.join(" ",this.getProducts().stream().map(p->p.toString()).collect(Collectors.toList()))
        ,this.getCreateUser().getUserName(),this.getStatus()
        );

    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
