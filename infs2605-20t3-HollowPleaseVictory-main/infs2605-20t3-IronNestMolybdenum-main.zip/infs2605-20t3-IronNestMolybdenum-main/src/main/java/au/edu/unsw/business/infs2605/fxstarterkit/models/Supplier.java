package au.edu.unsw.business.infs2605.fxstarterkit.models;

import au.edu.unsw.business.infs2605.fxstarterkit.dao.OrderDao;
import au.edu.unsw.business.infs2605.fxstarterkit.dao.UserDao;

import java.util.ArrayList;
import java.util.List;

public class Supplier extends BaseModel{
    private String supplierName;
    private String phoneNumber;
    private String address;
    public Supplier(){}
    public Supplier(String supplierName, String phoneNumber, String address) {
        this.supplierName = supplierName;
        this.phoneNumber = phoneNumber;
        this.address = address;
    }


    public List<User> getUsers(){
        if(getId()>0){
           return  UserDao.getUserDao().getSupplierUsers(getId());
        }
        return new ArrayList<>();
    }
    public List<Order> getOrders(){
        if(getId()>0){
            return OrderDao.getOrderDao().findSupplierOrder(getId());
        }
        return new ArrayList<>();
    }
    public String getSupplierName() {
        return supplierName;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String getTableName() {
        return "supplier";
    }

    @Override
    public String toStringForSearch() {
        return null;
    }
}
