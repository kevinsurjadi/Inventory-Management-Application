package au.edu.unsw.business.infs2605.fxstarterkit.controller.product;

import au.edu.unsw.business.infs2605.fxstarterkit.controller.BaseTableController;
import au.edu.unsw.business.infs2605.fxstarterkit.dao.ProductDao;
import au.edu.unsw.business.infs2605.fxstarterkit.models.Product;
import au.edu.unsw.business.infs2605.fxstarterkit.observers.Observable;
import au.edu.unsw.business.infs2605.fxstarterkit.observers.Observer;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.AppUtil;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.UIUtil;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

public class SelectProductController extends BaseTableController<Product> {
    public TableColumn productNameCol;
    public TableColumn productTypeCol;
    public TableColumn priceCol;
    public TableColumn createTimeCol;
    public TableColumn updateTimeCol;

    @Override
    protected TableView<Product> getTableView() {
        return this.tableView;
    }

    @Override
    protected TextField getTextFieldSearch() {
        return null;
    }

    @Override
    public void initTableData() {
        List<Product> products = ProductDao.getProductDao().listAll();
        observableList = FXCollections.observableArrayList();
        observableList.addAll(products);
        this.tableView.setItems(observableList);
    }


    public void initialize(URL location, ResourceBundle resources) {

        this.productNameCol.setCellValueFactory(
                new PropertyValueFactory<Product, String>("productName"));
        priceCol.setCellValueFactory(
                new PropertyValueFactory<Product, String>("price"));
        productTypeCol.setCellValueFactory(
                new PropertyValueFactory<Product, String>("productType"));
        createTimeCol.setCellValueFactory(
                new PropertyValueFactory<Product, Date>("createTime"));
        updateTimeCol.setCellValueFactory(
                new PropertyValueFactory<Product, Date>("updateTime"));
        this.setColDateFormat(createTimeCol);
        this.setColDateFormat(updateTimeCol);
        this.initTableData();

    }

    @Override
    public void updateModel(Product product) {

    }

    @Override
    public void onAdded(Product product) {

    }

    @Override
    public void onDeleted(Product product) {

    }

    @Override
    public void onEdit(Product product) {

    }

    @Override
    public void onSelected(Product product) {

    }

    public void doSelect(ActionEvent actionEvent) {

        if (getSelectionItem() != null) {
            AppUtil.modelMap.put("SelectProduct", getSelectionItem());
            Observable.onSelected(Observer.SelectProduct,null);
            this.closeWindow();
        }else{
            UIUtil.alert("Please select one.");
        }

    }

    public void doCancel(ActionEvent actionEvent) {
        this.closeWindow();
    }
}
