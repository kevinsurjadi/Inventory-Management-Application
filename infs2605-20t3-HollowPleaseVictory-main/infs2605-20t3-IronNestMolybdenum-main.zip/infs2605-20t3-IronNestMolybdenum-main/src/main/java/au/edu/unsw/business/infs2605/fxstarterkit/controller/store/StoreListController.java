package au.edu.unsw.business.infs2605.fxstarterkit.controller.store;

import au.edu.unsw.business.infs2605.fxstarterkit.controller.BaseTableController;
import au.edu.unsw.business.infs2605.fxstarterkit.dao.StoreDao;
import au.edu.unsw.business.infs2605.fxstarterkit.models.Store;
import au.edu.unsw.business.infs2605.fxstarterkit.observers.Observable;
import au.edu.unsw.business.infs2605.fxstarterkit.observers.Observer;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.AppUtil;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.UIUtil;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

public class StoreListController extends BaseTableController<Store>{
    public TableColumn storeMangerCol;
    public TableColumn phoneNumberCol;
    public TableColumn addressCol;
    public TableColumn createTimeCol;
    public TableColumn storeNameCol;
    private List<Store> stores;
    private ObservableList<Store> data;



    @Override
    protected TableView<Store> getTableView() {
        return this.tableView;
    }

    @Override
    protected TextField getTextFieldSearch() {
        return this.searchTextField;
    }

    @Override
    public void initTableData() {
        stores= StoreDao.getStoreDao().listAll();
        observableList = FXCollections.observableArrayList();
        observableList.addAll(stores);
        this.tableView.getItems().clear();
        this.tableView.setItems(observableList);
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        super.initialize(location,resources);
        this.storeMangerCol.setCellValueFactory(
                new PropertyValueFactory<Store,String>("storeManger"));
        this.storeNameCol.setCellValueFactory(
                new PropertyValueFactory<Store,String>("storeName"));
        phoneNumberCol.setCellValueFactory(
                new PropertyValueFactory<Store,String>("phoneNumber"));
        addressCol.setCellValueFactory(
                new PropertyValueFactory<Store,String>("address"));
        createTimeCol.setCellValueFactory(
                new PropertyValueFactory<Store, Date>("createTime"));

        Observable.registerObserver(Observer.AddStore,this);
        Observable.registerObserver(Observer.EditStore,this);
        Observable.registerObserver(Observer.DeleteEvent,this);

        this.initTableData();
    }

    @Override
    public void onAdded(Store store) {
        this.initTableData();
    }

    @Override
    public void onDeleted(Store store) {
            this.initTableData();
    }

    @Override
    public void onEdit(Store store) {

    }

    @Override
    public void onSelected(Store store) {

    }

    public void addStore(ActionEvent actionEvent) {
        if(AppUtil.loginUser.getUserType()>0){
            UIUtil.alert("Unauthorized operation.");
            return ;
        }
        AppUtil.modelMap.remove("newOrEditStore");
        UIUtil.showView("fxml/store/addOrEditStore.fxml","add Store",false);
    }

    public void editStore(ActionEvent actionEvent) {
        if(AppUtil.loginUser.getUserType()>0){
            UIUtil.alert("Unauthorized operation.");
            return ;
        }
        if (getSelectionItem() != null) {
            AppUtil.modelMap.put("newOrEditStore", getSelectionItem());
            UIUtil.showView("fxml/store/addOrEditStore.fxml","Edit Store",false);
        }else{
            UIUtil.alert("Please select one.");
        }
    }

    public void deleteStore(ActionEvent actionEvent) {
        if(AppUtil.loginUser.getUserType()>0){
            UIUtil.alert("Unauthorized operation.");
            return ;
        }
        if (getSelectionItem() != null) {
           if (UIUtil.showConfirmation()) {
                StoreDao.getStoreDao().delete(getSelectionItem());
//                this.initTableData();
               Observable.onDeleted(Observer.DeleteEvent,null);
           }
        }
    }

    @Override
    public void updateModel(Store store) {

    }
}
