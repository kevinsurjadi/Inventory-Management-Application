package au.edu.unsw.business.infs2605.fxstarterkit.dao;

import au.edu.unsw.business.infs2605.fxstarterkit.models.Order;
import au.edu.unsw.business.infs2605.fxstarterkit.models.OrderProduct;
import au.edu.unsw.business.infs2605.fxstarterkit.models.Product;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.DBUtil;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.DateUtil;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.SQL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class OrderDao extends BaseDao<Order> {


    private static OrderDao orderDao = new OrderDao();

    public static OrderDao getOrderDao(){
        return orderDao;
    }

    private OrderDao() {
    }

    @Override
    public void deleteById(int id) {
            this.delete(findById(id));
    }

    @Override
    public void delete(Order order) {
        List<OrderProduct> ops = order.getProducts(true);
        for(OrderProduct op:ops){
            OrderProductDao.getOrderProductDao().delete(op);
        }
        super.deleteById(order.getId());
    }

    //    public void deleteUserOrder()
    public List<Order> findUserOrder(int userId){
        List<Order> data = new ArrayList<>();
        System.out.println(SQL.selectSQL(getTableName()));
        try (Connection connection = DBUtil.createConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SQL.UserOrderSQL)) {
            preparedStatement.setInt(1, userId);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                data.add(this.result2Model(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return data;
    }

    public List<Order> findStoreOrder(int storeId){
        List<Order> data = new ArrayList<>();
        System.out.println(SQL.selectSQL(getTableName()));
        try (Connection connection = DBUtil.createConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SQL.StoreOrderSQL)) {
            preparedStatement.setInt(1, storeId);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                data.add(this.result2Model(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return data;
    }


    public List<String[]> getStatusData(){
        List<String[]> data = new ArrayList<>();
        System.out.println(SQL.selectSQL(getTableName()));
        try (Connection connection = DBUtil.createConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SQL.StatusOrderSQL)) {

            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
               String[]d=new String[2];
               d[0]=resultSet.getString(1);
               d[1]=resultSet.getString(2);
               data.add(d);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return data;
    }


    public List<Order> findSupplierOrder(int supplierId){
        List<Order> data = new ArrayList<>();
        System.out.println(SQL.selectSQL(getTableName()));
        try (Connection connection = DBUtil.createConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SQL.SupplierOrderSQL)) {
            preparedStatement.setInt(1, supplierId);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                data.add(this.result2Model(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return data;
    }

    @Override
    public void save(Order order) {
        if (order.getId() > 0)
            this.update(order);
        else {
            try (Connection connection = DBUtil.createConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement(SQL.InsertOrderSQL)) {
//                (supplierId,storeId,userId,supplierName,status)
                preparedStatement.setInt(1, order.getSupplierId());
                preparedStatement.setInt(2, order.getStoreId());
                preparedStatement.setInt(3, order.getUserId());
                preparedStatement.setString(4, order.getSupplierName());
                preparedStatement.setString(5, order.getStatus());

                preparedStatement.executeUpdate();
                //return id
                ResultSet generatedKeys = preparedStatement.getGeneratedKeys();
                int oid=0;
                while(generatedKeys.next()){
                    oid=generatedKeys.getInt(1);
                }
                for(OrderProduct op:order.getProducts(false)){
                    op.setOrderId(oid);
                    OrderProductDao.getOrderProductDao().save(op);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void update(Order order) {
        try (Connection connection = DBUtil.createConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SQL.UpdateOrderSQL)) {

//            updateTime=?,supplierId=?,storeId=?,userId=?,supplierName=?,status=? " +
//            ",finishTime=?,cancelTime=?,carriageTime=?

            preparedStatement.setString(1, DateUtil.date2Str(new java.util.Date()));
            preparedStatement.setInt(2, order.getSupplierId());
            preparedStatement.setInt(3, order.getStoreId());
            preparedStatement.setInt(4, order.getUserId());
            preparedStatement.setString(5, order.getSupplierName());
            preparedStatement.setString(6, order.getStatus());
            preparedStatement.setString(7, order.getFinishTime() == null ? null : DateUtil.date2Str(order.getFinishTime()));
            preparedStatement.setString(8, order.getCancelTime() == null ? null : DateUtil.date2Str(order.getCancelTime()));
            preparedStatement.setString(9, order.getCarriageTime() == null ? null : DateUtil.date2Str(order.getCarriageTime()));

            preparedStatement.setInt(10, order.getId());
            preparedStatement.executeUpdate();

            for(OrderProduct op:order.getProducts(false)){
                op.setOrderId(order.getId());
                OrderProductDao.getOrderProductDao().save(op);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    String getTableName() {
        return "`order`";
    }

    @Override
    Order result2Model(ResultSet resultSet) {
        Order order = new Order();
        try {
            order.setId(resultSet.getInt("id"));
            order.setCreateTime(DateUtil.str2Date(resultSet.getString("createTime")));
            order.setUpdateTime(DateUtil.str2Date(resultSet.getString("updateTime")));

            order.setSupplierId(resultSet.getInt("supplierId"));
            order.setStoreId(resultSet.getInt("storeId"));
            order.setUserId(resultSet.getInt("userId"));
            order.setSupplierName(resultSet.getString("supplierName"));
            order.setStatus(resultSet.getString("status"));
            String d=resultSet.getString("finishTime");
            order.setFinishTime(d==null?null:DateUtil.str2Date(d));
            d=resultSet.getString("cancelTime");
            order.setCancelTime(d==null?null:DateUtil.str2Date(d));
            d=resultSet.getString("carriageTime");
            order.setCancelTime(d==null?null:DateUtil.str2Date(d));


        } catch (SQLException e) {
            e.printStackTrace();
        }
        return order;
    }
}
