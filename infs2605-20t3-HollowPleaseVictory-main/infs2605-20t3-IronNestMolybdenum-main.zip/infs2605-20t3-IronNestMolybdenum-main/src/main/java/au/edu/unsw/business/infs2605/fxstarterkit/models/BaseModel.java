package au.edu.unsw.business.infs2605.fxstarterkit.models;

import java.util.Date;

public abstract class BaseModel {
    private int id;
    private Date createTime;
    private Date updateTime;

    public abstract String getTableName();
    public abstract String toStringForSearch();
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}
