package au.edu.unsw.business.infs2605.fxstarterkit.controller.user;

import au.edu.unsw.business.infs2605.fxstarterkit.controller.BaseTableController;
import au.edu.unsw.business.infs2605.fxstarterkit.dao.StoreDao;
import au.edu.unsw.business.infs2605.fxstarterkit.dao.UserDao;
import au.edu.unsw.business.infs2605.fxstarterkit.models.BaseModel;
import au.edu.unsw.business.infs2605.fxstarterkit.models.Supplier;
import au.edu.unsw.business.infs2605.fxstarterkit.models.User;
import au.edu.unsw.business.infs2605.fxstarterkit.observers.Observable;
import au.edu.unsw.business.infs2605.fxstarterkit.observers.Observer;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.AppUtil;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.UIUtil;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;

import java.net.URL;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

public class UserListController extends BaseTableController<User> {
    public TableView userListTableView;
    public TableColumn userNameCol;
    public TableColumn fullNameCol;
    public TableColumn userTypeCol;
    public TableColumn ssCol;
    public TableColumn createTimeCol;
    private List<User> users;


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        super.initialize(location,resources);

        userNameCol.setCellValueFactory(
                new PropertyValueFactory<User,String>("userName"));
        fullNameCol.setCellValueFactory(
                new PropertyValueFactory<User,String>("password"));
        userTypeCol.setCellValueFactory(
                new PropertyValueFactory<User,String>("userTypeName"));
        ssCol.setCellValueFactory(
                new PropertyValueFactory<User,String>("ssName"));
        createTimeCol.setCellValueFactory(
                new PropertyValueFactory<User, Date>("createTime"));



        fullNameCol.setCellFactory(TextFieldTableCell.forTableColumn());

        Observable.registerObserver(Observer.AddOrEditUser,this);
        Observable.registerObserver(Observer.DeleteEvent,this);


      this.initTableData();
    }

    public void addUser(ActionEvent actionEvent) {
        if(AppUtil.loginUser.getUserType()>0){
            UIUtil.alert("Unauthorized operation.");
            return ;
        }
        AppUtil.modelMap.remove("newOrEditUser");
        UIUtil.showView("fxml/user/addOrEditUser.fxml","add/Edit User",false);
    }

    public void editUser(ActionEvent actionEvent) {
        if(AppUtil.loginUser.getUserType()>0){
            UIUtil.alert("Unauthorized operation.");
            return ;
        }
        if (getSelectionItem() != null) {
            AppUtil.modelMap.put("newOrEditUser", getSelectionItem());
            UIUtil.showView("fxml/user/addOrEditUser.fxml","add/Edit User",false);
        }else{
            UIUtil.alert("Please select one.");
        }
    }

    public void deleteUser(ActionEvent actionEvent) {
        if(AppUtil.loginUser.getUserType()>0){
            UIUtil.alert("Unauthorized operation.");
            return ;
        }
        if (getSelectionItem() != null) {
            if (UIUtil.showConfirmation()) {
                UserDao.getUserDao().delete(getSelectionItem());
//                this.initTableData();
                Observable.onDeleted(Observer.DeleteEvent,null);
            }
        }else{
            UIUtil.alert("Please select one.");
        }
//        this.observableList.add(new User("a","b","c",0,0));
    }

    @Override
    protected TableView<User> getTableView() {
        return this.userListTableView;
    }

    @Override
    protected TextField getTextFieldSearch() {
        return this.searchTextField;
    }

    @Override
    public void initTableData() {
        observableList = FXCollections.observableArrayList();
        if(AppUtil.loginUser.getUserType()>0){
            observableList.add(AppUtil.loginUser);
        }else{
            users=UserDao.getUserDao().listAll();

            observableList.addAll(users);
        }

        this.userListTableView.setItems(observableList);
    }

    @Override
    public void onAdded(User user) {
        this.initTableData();
    }

    @Override
    public void onDeleted(User user) {
        this.initTableData();
    }

    @Override
    public void onEdit(User user) {
        this.initTableData();
    }

    @Override
    public void onSelected(User user) {


    }

    @Override
    public void updateModel(User user) {

    }
}
