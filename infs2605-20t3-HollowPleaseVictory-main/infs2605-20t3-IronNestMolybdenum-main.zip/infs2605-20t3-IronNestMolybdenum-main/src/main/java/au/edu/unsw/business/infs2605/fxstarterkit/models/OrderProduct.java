package au.edu.unsw.business.infs2605.fxstarterkit.models;

public class OrderProduct extends BaseModel {
    private int orderId;
    private int productId;
    private String productName;
    private int quantity;

    public String getQuantityStr() {
        if (quantityStr == null)
            setQuantityStr(this.getQuantity() + "");
        return quantityStr;
    }

    public void setQuantityStr(String quantityStr) {
        this.quantityStr = quantityStr;
        try {
            this.quantity = Integer.parseInt(quantityStr);
        } catch (Exception e) {

        }
    }

    private String quantityStr;

    public OrderProduct() {
    }

    public OrderProduct(int orderId, int productId, String productName, int quantity) {
        this.orderId = orderId;
        this.productId = productId;
        this.productName = productName;
        this.quantity = quantity;
    }

    public String toString() {
        return String.format("[%s,%d]", this.productName, this.quantity);
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }


    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @Override
    public String getTableName() {
        return "orderProduct";
    }

    @Override
    public String toStringForSearch() {
        return null;
    }
}
