package au.edu.unsw.business.infs2605.fxstarterkit.controller.user;

import au.edu.unsw.business.infs2605.fxstarterkit.controller.BaseController;
import au.edu.unsw.business.infs2605.fxstarterkit.controller.BaseTableController;
import au.edu.unsw.business.infs2605.fxstarterkit.models.User;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ResourceBundle;

public class SelectUserController extends BaseTableController<User> {
    @Override
    public void updateModel(User user) {

    }

    @Override
    protected TableView<User> getTableView() {
        return null;
    }

    @Override
    protected TextField getTextFieldSearch() {
        return null;
    }

    @Override
    public void initTableData() {

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
//        this.tableView
    }

    @Override
    public void onAdded(User user) {

    }

    @Override
    public void onDeleted(User user) {

    }

    @Override
    public void onEdit(User user) {

    }

    @Override
    public void onSelected(User user) {

    }
}
