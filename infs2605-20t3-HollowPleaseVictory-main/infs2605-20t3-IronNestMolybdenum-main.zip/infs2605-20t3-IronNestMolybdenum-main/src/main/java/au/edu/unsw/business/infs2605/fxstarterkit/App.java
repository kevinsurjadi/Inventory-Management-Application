package au.edu.unsw.business.infs2605.fxstarterkit;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.AppUtil;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.DBUtil;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

import java.io.IOException;
import java.net.URL;

public class App extends Application {
    public static Scene scene;
    public static Stage mainStage=null;
    @Override
    public void start(Stage stage) throws IOException {
        scene = new Scene(loadFXML("fxml/login"), 414 , 414);

//        URL r=getClass().getClassLoader().getResource("fxml/login.fxml");
//        Parent root = FXMLLoader.load(r);
//        scene= new Scene(root, 414, 414);
        stage.setScene(scene);
        mainStage=stage;
        stage.setOnCloseRequest(new EventHandler<WindowEvent>(){
            @Override
            public void handle(WindowEvent event){
                System.out.println("exit");
            }
        });
        AppUtil.mainStage=stage;
        AppUtil.scene=scene;
        stage.show();
    }

   public static void setRoot(String fxml) throws IOException {
        scene.setRoot(loadFXML(fxml));
    }

    public static Parent loadFXML(String fxml) throws IOException {
        
        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource(fxml +(fxml.endsWith(".fxml")?"" : ".fxml")));
        return fxmlLoader.load();
    }
    public static void main(String[] args) {
        DBUtil.initDB(false);
//        DBUtil.initDB(true);
        launch();
    }
}
