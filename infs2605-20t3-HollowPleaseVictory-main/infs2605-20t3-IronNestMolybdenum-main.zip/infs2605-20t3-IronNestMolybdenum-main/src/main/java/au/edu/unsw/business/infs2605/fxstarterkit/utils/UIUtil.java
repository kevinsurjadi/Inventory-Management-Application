package au.edu.unsw.business.infs2605.fxstarterkit.utils;

import au.edu.unsw.business.infs2605.fxstarterkit.App;
import au.edu.unsw.business.infs2605.fxstarterkit.observers.Observable;
import au.edu.unsw.business.infs2605.fxstarterkit.observers.Observer;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Optional;

public class UIUtil {
    public static void alert(String message){
        Alert _alert = new Alert(Alert.AlertType.WARNING);
        _alert.setTitle("message");
        _alert.setHeaderText(null);
        _alert.setContentText(message);
        _alert.initOwner(App.mainStage);
        _alert.show();
    }
    public static FXMLLoader showView(String viewPath, String viewTitle, boolean resizable, Observer observer,String event) {
        Stage stage = new Stage();
        Parent root = null;
//        FXMLLoader loader = new FXMLLoader(UIUtil.class.getResource(viewPath));
        try {
//            root = loader.load();
            root=App.loadFXML(viewPath);
        } catch (IOException e) {
            e.printStackTrace();
        }
//        stage.getIcons().add(new Image(UiConstants.Path.VADIMKSN));
        stage.setTitle(viewTitle);
        stage.setScene(new Scene(root));
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setResizable(resizable);
        if(null!=event){
            Observable.registerObserver(event,observer);
            stage.setOnCloseRequest(v->{
                Observable.removeObserver(observer);
            });
        }
        stage.show();
        return null;
    }
    public static FXMLLoader showView(String viewPath, String viewTitle, boolean resizable) {
        return showView(viewPath,viewTitle,resizable,null,null);
    }

    public static boolean showConfirmation() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation");
        alert.setHeaderText(null);
        alert.setContentText("Are you sure?");
        Optional<ButtonType> result = alert.showAndWait();
        return result.get() == ButtonType.OK;
    }
}
