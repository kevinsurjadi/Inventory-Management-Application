package au.edu.unsw.business.infs2605.fxstarterkit.controller.order;

import au.edu.unsw.business.infs2605.fxstarterkit.controller.BaseController;
import au.edu.unsw.business.infs2605.fxstarterkit.dao.OrderDao;
import au.edu.unsw.business.infs2605.fxstarterkit.models.Order;
import javafx.event.ActionEvent;
import javafx.geometry.Side;
import javafx.scene.chart.PieChart;

import java.net.URL;
import java.util.ResourceBundle;

public class OrderStatisticsController extends BaseController<Order> {

    public PieChart pieChart;


    @Override
    public void updateModel(Order order) {

    }

    @Override
    public void onAdded(Order order) {

    }

    @Override
    public void onDeleted(Order order) {

    }

    @Override
    public void onEdit(Order order) {

    }

    @Override
    public void onSelected(Order order) {

    }


    private void loadData(){
        for(String[]d: OrderDao.getOrderDao().getStatusData()){
            pieChart.getData().add(new PieChart.Data(d[0],Integer.parseInt(d[1])));
        }
        pieChart.setLegendSide(Side.LEFT);
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        loadData();
    }

    public void doRefresh(ActionEvent actionEvent) {
        loadData();
    }
}
