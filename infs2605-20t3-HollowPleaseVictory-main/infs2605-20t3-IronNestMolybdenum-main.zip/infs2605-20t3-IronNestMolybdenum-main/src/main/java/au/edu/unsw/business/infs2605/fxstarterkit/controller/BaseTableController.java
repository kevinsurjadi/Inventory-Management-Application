package au.edu.unsw.business.infs2605.fxstarterkit.controller;

import au.edu.unsw.business.infs2605.fxstarterkit.dao.UserDao;
import au.edu.unsw.business.infs2605.fxstarterkit.models.BaseModel;
import au.edu.unsw.business.infs2605.fxstarterkit.models.User;
import au.edu.unsw.business.infs2605.fxstarterkit.observers.Observer;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.DateUtil;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.AnchorPane;

import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

public abstract class BaseTableController <T extends BaseModel> extends  BaseController<T> implements   Observer<T> {


    @FXML
    public TableView   tableView;
    @FXML
    public TextField searchTextField;

    protected ObservableList<T> observableList;

    protected abstract TableView<T> getTableView();

    protected abstract TextField getTextFieldSearch();

    public abstract void initTableData();

    private int getSelectedId() {
        return getTableView().getSelectionModel().getSelectedIndex();
    }

    public T getSelectionItem() {
        int id = getSelectedId();
        if (id != -1) {
            return observableList.get(id);
        } else return null;
    }

    public void initialize(URL location, ResourceBundle resources) {
        if(searchTextField!=null){
            searchTextField.textProperty().addListener((observable, oldValue, newValue) -> search());
        }
    }
    protected void search() {
        String stringForSearch = getTextFieldSearch().getText();

        if (stringForSearch.isEmpty()) {
            getTableView().setItems(observableList);
        } else {
            List<T> models = new ArrayList<>();
            for (T model : observableList) {
                if (model.toStringForSearch().contains(stringForSearch))
                    models.add(model);
            }
            ObservableList<T> newList = FXCollections.observableArrayList(models);
            getTableView().setItems(newList);
        }
    }

    protected  void setColDateFormat(TableColumn columnDate){
        columnDate.setCellFactory(column -> {
            TableCell<T, Date> cell = new TableCell<T, Date>() {
                @Override
                protected void updateItem(Date item, boolean empty) {
                    super.updateItem(item, empty);
                    if(empty) {
                        setText(null);
                    }
                    else {
                        if(item != null)
                            this.setText(DateUtil.date2Str(item));
                    }
                }
            };
            return cell;
        });
    }
}
