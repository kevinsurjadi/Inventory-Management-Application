package au.edu.unsw.business.infs2605.fxstarterkit.dao;

import au.edu.unsw.business.infs2605.fxstarterkit.models.Order;
import au.edu.unsw.business.infs2605.fxstarterkit.models.OrderProduct;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.DBUtil;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.DateUtil;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.SQL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OrderProductDao extends BaseDao<OrderProduct> {

    private static OrderProductDao orderProductDao=new OrderProductDao();

    private OrderProductDao(){}

    public static OrderProductDao getOrderProductDao(){
        return orderProductDao;
    }

    public List<OrderProduct> findByOrderId(int orderId){
        List<OrderProduct> data = new ArrayList<>();
        System.out.println(SQL.selectSQL(getTableName()));
        try (Connection connection = DBUtil.createConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SQL.FindOrderProductByOrderIdSQL)) {
            preparedStatement.setInt(1,orderId);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                data.add(this.result2Model(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return data;
    }

    @Override
    public void save(OrderProduct orderProduct) {
        if (orderProduct.getId() > 0)
            this.update(orderProduct);
        else {
            try (Connection connection = DBUtil.createConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement(SQL.InsertOrderProductSQL)) {
//                (orderId,productId,productName,quantity)
                preparedStatement.setInt(1, orderProduct.getOrderId());
                preparedStatement.setInt(2, orderProduct.getProductId());
                preparedStatement.setString(3, orderProduct.getProductName());
                preparedStatement.setInt(4, orderProduct.getQuantity());

                preparedStatement.executeUpdate();

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void update(OrderProduct orderProduct) {
        try (Connection connection = DBUtil.createConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SQL.UpdateOrderProductSQL)) {

//            updateTime=?,supplierId=?,storeId=?,userId=?,supplierName=?,status=? " +
//            ",finishTime=?,cancelTime=?,carriageTime=?
            preparedStatement.setString(1, DateUtil.date2Str(new java.util.Date()));
            preparedStatement.setInt(2, orderProduct.getOrderId());
            preparedStatement.setInt(3, orderProduct.getProductId());
            preparedStatement.setString(4, orderProduct.getProductName());
            preparedStatement.setInt(5, orderProduct.getQuantity());

            preparedStatement.setInt(6, orderProduct.getId());
            preparedStatement.executeUpdate();


        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    String getTableName() {
        return "orderProduct";
    }

    @Override
    OrderProduct result2Model(ResultSet resultSet) {
        OrderProduct orderProduct = new OrderProduct();
        try {
            orderProduct.setId(resultSet.getInt("id"));
            orderProduct.setCreateTime(DateUtil.str2Date(resultSet.getString("createTime")));
            orderProduct.setUpdateTime(DateUtil.str2Date(resultSet.getString("updateTime")));

            orderProduct.setOrderId(resultSet.getInt("orderId"));
            orderProduct.setProductId(resultSet.getInt("productId"));
            orderProduct.setProductName(resultSet.getString("productName"));
            orderProduct.setQuantity(resultSet.getInt("quantity"));

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orderProduct;
    }
}
