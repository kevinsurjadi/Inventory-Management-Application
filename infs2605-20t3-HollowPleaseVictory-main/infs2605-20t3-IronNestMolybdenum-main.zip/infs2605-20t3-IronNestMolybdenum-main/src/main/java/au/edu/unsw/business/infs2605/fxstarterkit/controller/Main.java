package au.edu.unsw.business.infs2605.fxstarterkit.controller;

import javafx.fxml.Initializable;

import java.net.URL;
import java.util.ResourceBundle;

public class Main implements Initializable {

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
}
