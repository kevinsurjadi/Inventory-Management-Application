package au.edu.unsw.business.infs2605.fxstarterkit.models;

import au.edu.unsw.business.infs2605.fxstarterkit.utils.DateUtil;

public class Product extends BaseModel{
    private String productName;
    private double price;
    private String productType;
    public Product(){}
    public Product(String productName, double price, String productType) {
        this.productName = productName;
        this.price = price;
        this.productType = productType;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    @Override
    public String getTableName() {
        return "product";
    }

    @Override
    public String toStringForSearch() {
        return String.join(" ",productName,productType,String.valueOf(price), DateUtil.date2Str(getCreateTime()),DateUtil.date2Str(getUpdateTime()));
    }
}
