package au.edu.unsw.business.infs2605.fxstarterkit.service;

import au.edu.unsw.business.infs2605.fxstarterkit.dao.UserDao;
import au.edu.unsw.business.infs2605.fxstarterkit.models.User;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.AppUtil;

public class UserService {

    private static UserService userService=new UserService();

    private UserService() {
    }

    public static UserService getUserService() {
        return userService;
    }

    public String doLogin(String userName, String password) {
        if(userName==null || "".equals(userName)){
            return "Please input username.";
        }
        if(password==null || "".equals(password)){
            return "Please input password.";
        }
        User u = UserDao.getUserDao().findByUserName(userName.trim());
        if (u == null) {
            return String.format("The user：%s does not exist.",userName);
        } else if (!u.getPassword().equals(password)) {
            return String.format("Password error.");
        }
        AppUtil.loginUser=u;
        return "";
    }

}
