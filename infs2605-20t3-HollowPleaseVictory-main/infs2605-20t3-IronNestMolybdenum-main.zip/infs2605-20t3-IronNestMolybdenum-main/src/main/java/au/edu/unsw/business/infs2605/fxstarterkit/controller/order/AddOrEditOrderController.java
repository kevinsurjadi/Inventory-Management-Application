package au.edu.unsw.business.infs2605.fxstarterkit.controller.order;

import au.edu.unsw.business.infs2605.fxstarterkit.controller.BaseTableController;
import au.edu.unsw.business.infs2605.fxstarterkit.dao.OrderDao;
import au.edu.unsw.business.infs2605.fxstarterkit.dao.ProductDao;
import au.edu.unsw.business.infs2605.fxstarterkit.models.*;
import au.edu.unsw.business.infs2605.fxstarterkit.observers.Observable;
import au.edu.unsw.business.infs2605.fxstarterkit.observers.Observer;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.AppUtil;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.DateUtil;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.UIUtil;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class AddOrEditOrderController extends BaseTableController<Order> {
    public Label storeLabel;
    public Label supplierLabel;
    public ComboBox statusSelect;
    public Label createUserLabel;
    public Label createTimeLabel;
    public Label CarriageTimeLabel;
    public Label CancelTimeLabel;
    public Label FinishTime;
    public TableColumn productNameCol;
    public TableColumn quantityCol;

    @Override
    protected TableView<Order> getTableView() {
        return this.tableView;
    }

    @Override
    protected TextField getTextFieldSearch() {
        return null;
    }


    protected ObservableList<OrderProduct> observableList;

    @Override
    public void initTableData() {
        observableList = FXCollections.observableArrayList();
        observableList.addAll(this.model.getProducts());
        this.tableView.setItems(observableList);
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        this.model = (Order) AppUtil.modelMap.getOrDefault("newOrEditOrder", new Order());

        this.statusSelect.getItems().addAll(Order.STATUS);

        this.statusSelect.getSelectionModel().selectedItemProperty().addListener((obs,o,n)->{
           this.model.setStatus(n.toString());
        });

        this.statusSelect.setValue(model.getStatus());

       if(this.model.getId()<=0){
           this.model.setCreateUser(AppUtil.loginUser);

           this.model.setUserId(AppUtil.loginUser.getId());
            this.model.setProducts(new ArrayList<>());
       }else{

           storeLabel.setText("Store: "+model.getStore().getStoreName());
           supplierLabel.setText("Store: "+model.getSupplier().getSupplierName());

           createTimeLabel.setText("CreateTime: "+ DateUtil.date2Str(model.getCreateTime()));
           if(model.getCancelTime()!=null)
               CancelTimeLabel.setText("CreateTime: "+ DateUtil.date2Str(model.getCancelTime()));
           if(model.getFinishTime()!=null)
               this.FinishTime.setText("FinishTime: "+ DateUtil.date2Str(model.getFinishTime()));
           if(model.getCarriageTime()!=null)
               this.CarriageTimeLabel.setText("CarriageTime: "+ DateUtil.date2Str(model.getCarriageTime()));

       }

       createUserLabel.setText("CreateUser:"+model.getCreateUser().getUserType());




        this.productNameCol.setCellValueFactory(
                new PropertyValueFactory<OrderProduct, String>("productName"));
        this.quantityCol.setCellValueFactory(
                new PropertyValueFactory<OrderProduct, String>("quantityStr"));

        tableView.setEditable(true);
        quantityCol.setCellFactory(TextFieldTableCell.forTableColumn());
        this.initTableData();
        this.resetEvent(true);
    }
    private  void resetEvent(boolean isAdd){
        Observable.removeEventObserver(Observer.SelectSupplier);
        Observable.removeEventObserver(Observer.SelectStore);
        Observable.removeEventObserver(Observer.SelectProduct);
        if(isAdd){
            Observable.registerObserver(Observer.SelectSupplier,this);
            Observable.registerObserver(Observer.SelectStore,this);
            Observable.registerObserver(Observer.SelectProduct,this);

        }


    }

    @Override
    public void updateModel(Order order) {

    }

    @Override
    public void onAdded(Order order) {

    }

    @Override
    public void onDeleted(Order order) {

    }

    @Override
    public void onEdit(Order order) {

    }

    @Override
    public void onSelected(Order order) {


        Supplier supplier = (Supplier)AppUtil.modelMap.getOrDefault("SelectSupplier", null);
        Store store = (Store)AppUtil.modelMap.getOrDefault("SelectStore", null);
        Product product = (Product)AppUtil.modelMap.getOrDefault("SelectProduct", null);

        if(supplier!=null){
            supplierLabel.setText("Supplier: "+supplier.getSupplierName());
            model.setSupplierId(supplier.getId());
//            model.setSsName(supplier.getSupplierName());
            AppUtil.modelMap.remove("SelectSupplier");
        }
        if(store!=null){
            model.setStoreId(store.getId());
            storeLabel.setText("Store: "+store.getStoreName());
            AppUtil.modelMap.remove("SelectStore");
        }
        if(product!=null){
            OrderProduct op=new OrderProduct(model.getId(),product.getId(),product.getProductName(),1);

            boolean exits=false;
            for(OrderProduct t:this.model.getProducts()){
                    if(t.getProductId()==op.getProductId()){
                        exits=true;
                    }
            }
            if(!exits){
                this.model.getProducts().add(op);
                this.observableList.add(op);
            }
        }

    }

    public void selectStore(ActionEvent actionEvent) {
        if(AppUtil.loginUser.getUserType()==2){
            UIUtil.alert("Unauthorized operation.");
            return ;
        }
        UIUtil.showView("fxml/store/selectStore.fxml","select Store",
                false);
    }

    public void selectSupplier(ActionEvent actionEvent) {
        if(AppUtil.loginUser.getUserType()==2){
            UIUtil.alert("Unauthorized operation.");
            return ;
        }
        UIUtil.showView("fxml/supplier/selectSupplier.fxml","select Supplier",
                false);
    }

    public void addProduct(ActionEvent actionEvent) {
        if(AppUtil.loginUser.getUserType()==2){
            UIUtil.alert("Unauthorized operation.");
            return ;
        }
        AppUtil.modelMap.remove("SelectProduct");
        UIUtil.showView("fxml/product/selectProduct.fxml", "add Product", false);
    }

    private OrderProduct getSelectionOrderProductItem() {
        int id = getTableView().getSelectionModel().getSelectedIndex();
        if (id != -1) {
            return observableList.get(id);
        } else return null;
    }

    public void delProduct(ActionEvent actionEvent) {
        if(AppUtil.loginUser.getUserType()==2){
            UIUtil.alert("Unauthorized operation.");
            return ;
        }
        if (getSelectionOrderProductItem() != null) {
            if (UIUtil.showConfirmation()) {
                this.model.getProducts().remove(getSelectionOrderProductItem());
                this.initTableData();
            }
        } else {
            UIUtil.alert("Please select one.");
        }
    }

    public void saveOrder(ActionEvent actionEvent) {

        if(this.model.getStoreId()<=0){
            UIUtil.alert("Please select Store.");
            return ;
        }
        if(this.model.getSupplierId()<=0){
            UIUtil.alert("Please select Supplier.");
            return ;
        }

        if(observableList.size()<=0){
            UIUtil.alert("Please select Products.");
            return ;
        }
        this.model.getProducts().clear();
        for(OrderProduct op :observableList ){
            this.model.getProducts().add(op);
        }

        OrderDao.getOrderDao().save(this.model);
        if(this.model.getId()>0){
            UIUtil.alert("Edit Order SUCCESS.");
        }else{
            UIUtil.alert("Add Order SUCCESS.");
        }

        this.closeWindow();
        AppUtil.modelMap.remove("AddOrEditOrder");
        Observable.onAdded(Observer.AddOrEditOrder,this.model);

        this.closeWindow();

    }

    public void cancelOrder(ActionEvent actionEvent) {
            this.closeWindow();
    }

    public void changeQuantity(TableColumn.CellEditEvent value) {
        TableColumn tc = value.getTableColumn();
        OrderProduct op= (OrderProduct) value.getRowValue();
        op.setQuantityStr((String) value.getNewValue());
        System.out.println(value.getRowValue()+" - "+value.getNewValue());
    }
}
