package au.edu.unsw.business.infs2605.fxstarterkit.dao;

import au.edu.unsw.business.infs2605.fxstarterkit.models.Store;
import au.edu.unsw.business.infs2605.fxstarterkit.models.User;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.DBUtil;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.DateUtil;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.SQL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class StoreDao extends BaseDao<Store> {


    private static StoreDao storeDao = new StoreDao();


    private StoreDao() {
    }

    public static StoreDao getStoreDao() {
        return storeDao;
    }


    @Override
    public void delete(Store store) {
        for(User u:store.getStoreUsers()){
            UserDao.getUserDao().delete(u);
        }
        super.deleteById(store.getId());
    }

    @Override
    public void deleteById(int id) {
        this.delete(findById(id));
    }

    @Override
    public void save(Store store) {
        if (store.getId() > 0)
            this.update(store);
        else {
            try (Connection connection = DBUtil.createConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement(SQL.InsertStoreSQL)) {

                preparedStatement.setString(1, store.getAddress());
                preparedStatement.setString(2, store.getPhoneNumber());
                preparedStatement.setString(3, store.getStoreManger());
                preparedStatement.setString(4, store.getStoreName());

                preparedStatement.executeUpdate();

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void update(Store store) {
        try (Connection connection = DBUtil.createConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SQL.UpdateStoreSQL)) {
            preparedStatement.setString(1, DateUtil.date2Str(new java.util.Date()));
            preparedStatement.setString(2, store.getAddress());
            preparedStatement.setString(3, store.getPhoneNumber());
            preparedStatement.setString(4, store.getStoreManger());
            preparedStatement.setString(5, store.getStoreName());
            preparedStatement.setInt(6, store.getId());
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    String getTableName() {
        return "store";
    }

    @Override
    Store result2Model(ResultSet resultSet) {
        Store store = new Store();
        try {
            store.setId(resultSet.getInt("id"));
            store.setCreateTime(DateUtil.str2Date(resultSet.getString("createTime")));
            store.setUpdateTime(DateUtil.str2Date(resultSet.getString("updateTime")));

            store.setPhoneNumber(resultSet.getString("phoneNumber"));
            store.setStoreManger(resultSet.getString("storeManger"));
            store.setAddress(resultSet.getString("address"));
            store.setStoreName(resultSet.getString("storeName"));

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return store;
    }
}
