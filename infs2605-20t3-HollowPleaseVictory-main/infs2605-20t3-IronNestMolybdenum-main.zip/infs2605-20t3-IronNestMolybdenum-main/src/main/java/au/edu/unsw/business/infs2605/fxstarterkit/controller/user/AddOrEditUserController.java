package au.edu.unsw.business.infs2605.fxstarterkit.controller.user;

import au.edu.unsw.business.infs2605.fxstarterkit.controller.BaseController;
import au.edu.unsw.business.infs2605.fxstarterkit.dao.UserDao;
import au.edu.unsw.business.infs2605.fxstarterkit.models.Store;
import au.edu.unsw.business.infs2605.fxstarterkit.models.Supplier;
import au.edu.unsw.business.infs2605.fxstarterkit.models.User;
import au.edu.unsw.business.infs2605.fxstarterkit.observers.Observable;
import au.edu.unsw.business.infs2605.fxstarterkit.observers.Observer;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.AppUtil;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.UIUtil;
import javafx.event.ActionEvent;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;

import java.net.URL;
import java.util.ResourceBundle;


public class AddOrEditUserController extends BaseController<User> {
    public TextField userNameTxt;
    public TextField fullNameTxt;
    public TextField pwdTxt;
    public ChoiceBox userTypeSelect;
    public Label ssNameLabel;
    public AnchorPane ssPane;

    @Override
    public void initialize(URL location, ResourceBundle resources) {


        this.userTypeSelect.getItems().addAll(User.USER_TYPES);

        this.userTypeSelect.getSelectionModel().selectedItemProperty().addListener((obs,o,n)->{
            int t=User.USER_TYPES_LIST.indexOf(n.toString());
            this.model.setAuthorityId(0);
            this.model.setUserType(User.USER_TYPES_LIST.indexOf(n.toString()));
            this.model.setUserTypeName(n.toString());
            this.ssPane.setVisible(this.model.getUserType()!=0);
            this.ssNameLabel.setText("");
        });
//        this.model=;

        setModel( (User) AppUtil.modelMap.getOrDefault("newOrEditUser", new User()));

        this.resetEvent(true);
    }

    private  void resetEvent(boolean isAdd){
        Observable.removeEventObserver(Observer.SelectSupplier);
        Observable.removeEventObserver(Observer.SelectStore);
        if(isAdd){
            Observable.registerObserver(Observer.SelectSupplier,this);
            Observable.registerObserver(Observer.SelectStore,this);
        }


    }

    @Override
    public void updateModel(User user) {
        this.userNameTxt.setText(user.getUserName());
        this.fullNameTxt.setText(user.getFullName());
        this.pwdTxt.setText(user.getPassword());

        System.out.println(user.getUserTypeName());
        this.userTypeSelect.setValue(user.getUserTypeName());

        this.ssNameLabel.setText(user.getSsName());
        this.ssPane.setVisible(this.model.getUserType()!=0);
    }


    public void selectStoreOrSupplier(ActionEvent actionEvent) {



        if(this.model.getUserType()==1){
            UIUtil.showView("fxml/store/selectStore.fxml","select Store",
                    false);
        }else if(this.model.getUserType()==2){
                UIUtil.showView("fxml/supplier/selectSupplier.fxml","select Supplier",
                        false);
        }

    }

    public void doSaveOrUpdate(ActionEvent actionEvent) {

        if (this.userNameTxt.getText().isEmpty()) {
            UIUtil.alert("Please input userName.");
            return;
        }
        if (this.fullNameTxt.getText().isEmpty()) {
            UIUtil.alert("Please input fullName.");
            return;
        }
        if (this.pwdTxt.getText().isEmpty()) {
            UIUtil.alert("Please input password.");
            return;
        }
        if (this.model.getUserType()>0 && this.model.getAuthorityId()<=0) {
            if(this.model.getUserType()==1){
                UIUtil.alert("Please select Store .");
            }else if(this.model.getUserType()==2){
                UIUtil.alert("Please select Supplier.");
            }
            return;
        }
        this.model.setUserName(this.userNameTxt.getText());
        this.model.setFullName(this.fullNameTxt.getText());
        this.model.setPassword(this.pwdTxt.getText());
        UserDao.getUserDao().save(this.model);
        if(this.model.getId()>0){
            UIUtil.alert("Edit user SUCCESS.");
        }else{
            UIUtil.alert("Add user SUCCESS.");
        }

        this.closeWindow();
        AppUtil.modelMap.remove("newOrEditUser");
        Observable.onAdded(Observer.AddOrEditUser,this.model);
    }

    public void doCancel(ActionEvent actionEvent) {
        this.closeWindow();
    }

    @Override
    public void onAdded(User user) {

    }

    @Override
    public void onDeleted(User user) {

    }

    @Override
    public void onEdit(User user) {

    }

    @Override
    public void onSelected(User user) {
        Supplier supplier = (Supplier)AppUtil.modelMap.getOrDefault("SelectSupplier", null);
        Store store = (Store)AppUtil.modelMap.getOrDefault("SelectStore", null);

        if(supplier!=null){
            ssNameLabel.setText(supplier.getSupplierName());
            model.setAuthorityId(supplier.getId());
            model.setSsName(supplier.getSupplierName());
            AppUtil.modelMap.remove("SelectSupplier");
        }if(store!=null){
            ssNameLabel.setText(store.getStoreName());
            model.setAuthorityId(store.getId());
            model.setSsName(store.getStoreName());
            AppUtil.modelMap.remove("SelectStore");
        }
    }
}
