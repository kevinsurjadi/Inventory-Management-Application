package au.edu.unsw.business.infs2605.fxstarterkit.controller;

import au.edu.unsw.business.infs2605.fxstarterkit.App;
import au.edu.unsw.business.infs2605.fxstarterkit.service.UserService;
import au.edu.unsw.business.infs2605.fxstarterkit.utils.UIUtil;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class LoginController implements Initializable {
    public TextField userNameTxt;
    public PasswordField passwordTxt;

    public void doLogin(ActionEvent actionEvent) {


        String msg=UserService.getUserService().doLogin(this.userNameTxt.getText().trim(),this.passwordTxt.getText().trim());

        if(msg.isEmpty()){
            try {
                App.setRoot("fxml/main");
                App.mainStage.setWidth(780);
                App.mainStage.setHeight(550);
                App.mainStage.setResizable(true);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }else{
            UIUtil.alert(msg);
        }
    }

    public void quit(ActionEvent actionEvent) {
        System.exit(0);
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
}
