package au.edu.unsw.business.infs2605.fxstarterkit.utils;

import au.edu.unsw.business.infs2605.fxstarterkit.models.BaseModel;
import au.edu.unsw.business.infs2605.fxstarterkit.models.User;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.util.HashMap;
import java.util.Map;

public class AppUtil {
    public static User loginUser;
    public static Scene scene;
    public static Stage mainStage=null;
    public static Map<String, BaseModel> modelMap=new HashMap<>();
}
