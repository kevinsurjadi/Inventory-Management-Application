module au.edu.unsw.business.infs2605.fxstarterkit {
    requires javafx.baseEmpty;
    requires javafx.base;
    requires javafx.fxmlEmpty;
    requires javafx.fxml;
    requires javafx.controlsEmpty;
    requires javafx.controls;
    requires javafx.graphicsEmpty;
    requires javafx.graphics;
    requires java.sql;
    opens au.edu.unsw.business.infs2605.fxstarterkit to javafx.fxml;
    opens au.edu.unsw.business.infs2605.fxstarterkit.controller to javafx.fxml;
    opens au.edu.unsw.business.infs2605.fxstarterkit.controller.order to javafx.fxml;
    opens au.edu.unsw.business.infs2605.fxstarterkit.controller.product to javafx.fxml;
    opens au.edu.unsw.business.infs2605.fxstarterkit.controller.supplier to javafx.fxml;
    opens au.edu.unsw.business.infs2605.fxstarterkit.controller.user to javafx.fxml;
    opens au.edu.unsw.business.infs2605.fxstarterkit.controller.store to javafx.fxml;
    
//    opens au.edu.unsw.business.infs2605.fxstarterkit.dao to javafx.base; 
    opens au.edu.unsw.business.infs2605.fxstarterkit.models to javafx.base; 
//    opens au.edu.unsw.business.infs2605.fxstarterkit.observers to javafx.base; 
//    opens au.edu.unsw.business.infs2605.fxstarterkit.service to javafx.base; 
//    opens au.edu.unsw.business.infs2605.fxstarterkit.utils to javafx.base; 
    
    exports au.edu.unsw.business.infs2605.fxstarterkit;
}