# infs2605-20t3-IronNestMolybdenum
infs2605-20t3-IronNestMolybdenum

# **Order System** .
## Used: [JavaFX], [SQLite], [Maven], JDBC.
## To see the **BONUS**, scroll down.

#### Show tabs: Users, Order, OrderStatistics, Store , Supplier

##User,Login model
#There are three types of accounts that can be logged in.<br><br>Administrator account has the largest permissions, the system default administrator account is admin, password is admin . In addition, three group members' zID and Fullname are set to three different types of username and password (adminTpye username: z5184030, password: HuidongLiu; StoreManagerType username: z5191392, password: JiadongHuang; SupplierStaffType username: z5205923, password: AndrewStevenson). The administrator's permission can do anything. <br> <br>Store manger have select permissions to very models,add/edit/delete order<br><br> Supplier staff can update the order's status.